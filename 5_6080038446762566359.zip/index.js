const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const { Button } = require("telegram/tl/custom/button");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const os = require("os");
const { execSync } = require("child_process");
const net = require("net");

const CONFIG = require("./config");
const {
  getUserJob, setUserJob, removeUserJob, isUserBuilding,
  getActiveJobs, getQueueStats,
} = require("./zip");
const {
  uploadZipToRelease, deleteRelease, triggerWorkflow, getRunStatus,
  getArtifacts, downloadArtifactZip, getFailedStepLog, sleep,
  createReleaseOnly, uploadAssetFile, triggerWeb2ApkWorkflow, publishRelease,
} = require("./server");

// ─── CLIENT ──────────────────────────────────────────────────────────────────
const SESSION_FILE = "./session.txt";
const sessionString = fs.existsSync(SESSION_FILE) ? fs.readFileSync(SESSION_FILE, "utf8").trim() : "";
const API_ID = parseInt(process.env.API_ID || "30595675");
const API_HASH = process.env.API_HASH || "c83857e908c6c83876ba692261127287";
const client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, { connectionRetries: 5 });

// ─── STATE ────────────────────────────────────────────────────────────────────
const userStates = new Map();
const adminStates = new Map();
const modStates = new Map();
const pendingOrders = new Map(); // orderId -> { userId, chatId, pkgKey, method, name, buyerUname, status }
const DIV_HTML = "━━━━━━━━━━━━━━━━━━━━";

// ─── FLUTTER MOD ──────────────────────────────────────────────────────────────
const fluttermod = require("./fluttermod");

// ─── IMAGE FETCH ─────────────────────────────────────────────────────────────
const { sendPhotoSafe, getImageBuffer } = require("./imagefetch");

// ─── ENKRIPSI HTML/JS ────────────────────────────────────────────────────────
const jsenc = require("./jsenc");

// ─── DEPLOY WEB KE VERCEL ──────────────────────────────────────────────────
const webdeploy = require("./webdeploy");
webdeploy.init({
  GITHUB_TOKEN: CONFIG.GITHUB_TOKEN,
  GITHUB_USERNAME: CONFIG.GITHUB_USERNAME,
  VERCEL_TOKEN: CONFIG.VERCEL_TOKEN,
  VERCEL_TEAM_ID: CONFIG.VERCEL_TEAM_ID,
});

// ─── CREDIT SYSTEM ───────────────────────────────────────────────────────────
const credits = require("./credits");
credits.initGithub(CONFIG.GITHUB_TOKEN, CONFIG.GITHUB_USERNAME, "bot-database-backup");
const CREDIT_COST = 1; // biaya credit per fitur utama (build, web2apk, deploy web, ganti domain/warna/icon/nama, enkripsi)
const BOT_USERNAME_FALLBACK = "botbuildziper";

// ─── FOTO NOTIFIKASI ────────────────────────────────────────────────────────
const NOTIF_PHOTOS = {
  build_apk:    CONFIG.PHOTO_BUILD_APK    || CONFIG.WELCOME_PHOTO,
  web2apk:      CONFIG.PHOTO_WEB2APK      || CONFIG.WELCOME_PHOTO,
  deploy_web:   CONFIG.PHOTO_DEPLOY_WEB   || CONFIG.WELCOME_PHOTO,
  enc_html:     CONFIG.PHOTO_ENC_HTML     || CONFIG.WELCOME_PHOTO,
  enc_js:       CONFIG.PHOTO_ENC_JS       || CONFIG.WELCOME_PHOTO,
  mod_domain:   CONFIG.PHOTO_MOD_DOMAIN   || CONFIG.WELCOME_PHOTO,
  mod_color:    CONFIG.PHOTO_MOD_COLOR    || CONFIG.WELCOME_PHOTO,
  mod_icon:     CONFIG.PHOTO_MOD_ICON     || CONFIG.WELCOME_PHOTO,
  mod_name:     CONFIG.PHOTO_MOD_NAME     || CONFIG.WELCOME_PHOTO,
  new_user:     CONFIG.PHOTO_NEW_USER     || CONFIG.WELCOME_PHOTO,
  report_bug:   CONFIG.PHOTO_REPORT_BUG   || CONFIG.WELCOME_PHOTO,
};

// ─── FILE PATHS ─────────────────────────────────────────────────────────────
const DB_PATH          = "./users.json";
const STATS_PATH       = "./stats.json";
const RESELLER_PATH    = "./resellers.json";
const BANNED_PATH      = "./banned.json";
const HISTORY_PATH     = "./buildhistory.json";
const MAINTENANCE_PATH = "./maintenance.json";

function ensureJson(p, def) {
  if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(def, null, 2));
}
ensureJson(DB_PATH,          []);
ensureJson(STATS_PATH,       { success: 0, failed: 0 });
ensureJson(RESELLER_PATH,    []);
ensureJson(BANNED_PATH,      []);
ensureJson(HISTORY_PATH,     []);
ensureJson(MAINTENANCE_PATH, { enabled: false, reason: "" });

// ─── DB ──────────────────────────────────────────────────────────────────────
const db = {
  getAllUsers:    ()       => JSON.parse(fs.readFileSync(DB_PATH, "utf-8")),
  getUserById:   (id)     => db.getAllUsers().find(u => u.userId === Number(id)),
  upsertUser(data) {
    const all = db.getAllUsers();
    const i = all.findIndex(u => u.userId === data.userId);
    if (i !== -1) { all[i] = { ...all[i], ...data, lastActive: new Date() }; }
    else { all.push({ ...data, joinedAt: new Date(), lastActive: new Date() }); }
    fs.writeFileSync(DB_PATH, JSON.stringify(all, null, 2));
    return i === -1;
  },
  deleteUser(id) {
    const all = db.getAllUsers();
    const filtered = all.filter(u => u.userId !== Number(id));
    if (filtered.length === all.length) return false;
    fs.writeFileSync(DB_PATH, JSON.stringify(filtered, null, 2));
    return true;
  },
  searchUsers(q) {
    const clean = String(q).toLowerCase().replace("@", "");
    return db.getAllUsers().filter(u =>
      String(u.userId).includes(clean) ||
      (u.username && u.username.toLowerCase().replace("@", "").includes(clean)) ||
      (u.name && u.name.toLowerCase().includes(clean))
    );
  },

  getStats()       { return JSON.parse(fs.readFileSync(STATS_PATH, "utf-8")); },
  incrementStat(t) {
    const s = db.getStats();
    s[t] = (s[t] || 0) + 1;
    fs.writeFileSync(STATS_PATH, JSON.stringify(s, null, 2));
    return s;
  },
  resetStats() {
    const s = { success: 0, failed: 0 };
    fs.writeFileSync(STATS_PATH, JSON.stringify(s, null, 2));
    return s;
  },

  blockedReportUsers: new Set(),
  isReportBlocked(id) { return this.blockedReportUsers.has(Number(id)); },
  blockReportUser(id) { this.blockedReportUsers.add(Number(id)); },
  unblockReportUser(id) { this.blockedReportUsers.delete(Number(id)); },
};

// ─── RESELLERS ──────────────────────────────────────────────────────────────
const rdb = {
  all()         { return JSON.parse(fs.readFileSync(RESELLER_PATH, "utf-8")); },
  save(list)    { fs.writeFileSync(RESELLER_PATH, JSON.stringify(list, null, 2)); },
  isReseller(id){ return rdb.all().some(r => r.userId === Number(id)); },
  add(id, username, addedBy) {
    const list = rdb.all();
    if (list.some(r => r.userId === Number(id))) return false;
    list.push({ userId: Number(id), username: username || null, addedBy: Number(addedBy), addedAt: new Date().toISOString() });
    rdb.save(list);
    return true;
  },
  remove(id) {
    const list = rdb.all();
    const f = list.filter(r => r.userId !== Number(id));
    if (f.length === list.length) return false;
    rdb.save(f);
    return true;
  },
};

// ─── BANNED ──────────────────────────────────────────────────────────────────
const bdb = {
  all()       { return JSON.parse(fs.readFileSync(BANNED_PATH, "utf-8")); },
  save(list)  { fs.writeFileSync(BANNED_PATH, JSON.stringify(list, null, 2)); },
  isBanned(id){ return bdb.all().some(b => b.userId === Number(id)); },
  ban(id, reason, bannedBy) {
    const list = bdb.all();
    if (list.some(b => b.userId === Number(id))) return false;
    list.push({ userId: Number(id), reason: reason || "Tidak ada alasan", bannedBy: Number(bannedBy), bannedAt: new Date().toISOString() });
    bdb.save(list);
    return true;
  },
  unban(id) {
    const list = bdb.all();
    const f = list.filter(b => b.userId !== Number(id));
    if (f.length === list.length) return false;
    bdb.save(f);
    return true;
  },
  getInfo(id) { return bdb.all().find(b => b.userId === Number(id)); },
};

// ─── BUILD HISTORY ──────────────────────────────────────────────────────────
const hdb = {
  all()     { return JSON.parse(fs.readFileSync(HISTORY_PATH, "utf-8")); },
  save(l)   { fs.writeFileSync(HISTORY_PATH, JSON.stringify(l, null, 2)); },
  add(entry) {
    const list = hdb.all();
    list.unshift({ ...entry, id: Date.now() });
    if (list.length > 500) list.splice(500);
    hdb.save(list);
  },
};

// ─── MAINTENANCE ────────────────────────────────────────────────────────────
const mdb = {
  get()          { return JSON.parse(fs.readFileSync(MAINTENANCE_PATH, "utf-8")); },
  save(d)        { fs.writeFileSync(MAINTENANCE_PATH, JSON.stringify(d, null, 2)); },
  isEnabled()    { return mdb.get().enabled; },
  toggle(reason) {
    const d = mdb.get();
    d.enabled = !d.enabled;
    d.reason = reason || "";
    mdb.save(d);
    return d.enabled;
  },
  setReason(r) {
    const d = mdb.get();
    d.reason = r;
    mdb.save(d);
  },
};

// ─── UTILS ──────────────────────────────────────────────────────────────────
function isAdmin(id)    { return CONFIG.ADMIN_IDS.includes(Number(id)); }
function isOwner(id)    { return Number(id) === Number(CONFIG.OWNER_ID); }
function isPrivileged(id){ return isAdmin(id) || isOwner(id); }

function getUserPriority(id) {
  if (isOwner(id))         return 1;
  if (rdb.isReseller(id))  return 2;
  return 3;
}

function getSortedActiveJobs() {
  return getActiveJobs().sort((a, b) => {
    const pa = a.priority || getUserPriority(a.userId);
    const pb = b.priority || getUserPriority(b.userId);
    return pa !== pb ? pa - pb : (a.updatedAt || 0) - (b.updatedAt || 0);
  });
}

function formatDuration(sec) {
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = [];
  if (h) p.push(`${h}j`);
  if (m) p.push(`${m}m`);
  p.push(`${s}d`);
  return p.join(" ");
}

function elapsedSec(since) { return Math.floor((Date.now() - since) / 1000); }
function progressBar(pct)  {
  const f = Math.round(pct / 10);
  return "▓".repeat(f) + "░".repeat(10 - f);
}
function tmpPath(n)  { return path.join(CONFIG.TMP_DIR, n); }
function genTag(id)  { return `build-${id}-${Date.now()}`; }
function cleanAlphaNum(text) {
  return (text || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 40);
}

function fmtDate(d) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtDateTime(d) {
  if (!d) return "—";
  return new Date(d).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function nowWib() {
  return new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}
function nowTimeWib() {
  return new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function statusLabel(s) {
  return ({ waiting_zip: "⏳ Menunggu ZIP", waiting_url: "🌐 Menunggu URL",
    waiting_appname: "📝 Menunggu Nama App", waiting_icon: "🖼️ Menunggu Icon",
    uploading: "☁️ Uploading", building: "⚙️ Building" }[s] || s);
}

// ─── CREDIT HELPERS ─────────────────────────────────────────────────────────
async function getReferralLink() {
  let uname = BOT_USERNAME_FALLBACK;
  try { uname = (await client.getMe()).username || uname; } catch (_) {}
  return { uname, link: (id) => `https://t.me/${uname}?start=${id}` };
}

// Definisi paket: key -> { label, credits (null = handled khusus), price, kind }
const CREDIT_PACKAGES = {
  "5":        { label: "5 Credit",   priceIDR: 2000,  credits: 5,     kind: "credit" },
  "10":       { label: "10 Credit",  priceIDR: 5000,  credits: 10,    kind: "credit" },
  "unlimited":{ label: "Unlimited", priceIDR: 8000,  credits: 99999, kind: "credit" },
  "reseller": { label: "Reseller",  priceIDR: 10000, credits: null,  kind: "reseller" },
};

function formatIDR(n) { return `Rp${Number(n).toLocaleString("id-ID")}`; }

function buyCreditKeyboard() {
  return [
    [{ text: `💳 5 Credit (${formatIDR(2000)})`, data: "buy_5" }, { text: `💳 10 Credit (${formatIDR(5000)})`, data: "buy_10" }],
    [{ text: `♾️ Unlimited (${formatIDR(8000)})`, data: "buy_unlimited" }, { text: `🤝 Reseller (${formatIDR(10000)})`, data: "buy_reseller" }],
    [{ text: "🎁 Redeem Kode", data: "redeem_start" }],
    [{ text: "🏠 Menu Utama", data: "start" }],
  ];
}

// Cek & potong 1 credit sebelum eksekusi fitur utama. Kalau kurang, kirim pesan & return false.
async function requireAndSpendCredit(chatId, userId, msgId = null) {
  if (isPrivileged(userId)) return true; // owner/admin unlimited
  if (!credits.hasCredit(userId, CREDIT_COST)) {
    const text =
      `💰 <b>Credit Kamu Habis!</b>\n${DIV_HTML}\n\n` +
      `<blockquote>Saldo kamu saat ini: <b>${credits.getCredits(userId)} credit</b>\n` +
      `Fitur ini butuh <b>${CREDIT_COST} credit</b>.\n\n` +
      `Kamu bisa dapat credit gratis dengan share link undangan kamu, atau beli langsung.</blockquote>`;
    if (msgId) await editHtml(chatId, msgId, text, buyCreditKeyboard());
    else await sendHtml(chatId, text, buyCreditKeyboard());
    return false;
  }
  credits.deductCredit(userId, CREDIT_COST);
  return true;
}

async function grantReferralBonusIfAny(userId) {
  const refBy = credits.confirmReferral(userId);
  if (!refBy) return;
  try {
    let name = "Unknown", username = "—";
    try {
      const e = await client.getEntity(userId);
      name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
      username = e?.username ? `@${e.username}` : "—";
    } catch (_) {}

    await client.sendMessage(refBy, {
      message:
        `🎉 <b>Bonus Referral Masuk!</b>\n${DIV_HTML}\n\n` +
        `<blockquote>👤 ${name} (${username}) baru saja join lewat link kamu.\n` +
        `💰 +${credits.REFERRAL_BONUS} credit ditambahkan ke saldo kamu!\n` +
        `💳 Saldo sekarang: <b>${credits.getCredits(refBy)} credit</b></blockquote>`,
      parseMode: "html",
    }).catch(() => {});
  } catch (_) {}
}

function roleTag(id) {
  if (isOwner(id))        return "👑 OWNER";
  if (rdb.isReseller(id)) return "🤝 RESELLER";
  if (isAdmin(id))        return "🔑 ADMIN";
  return "👤 USER";
}

function priorityTag(id) {
  if (isOwner(id))        return "👑 OWNER PRIORITY (Lv.1)";
  if (rdb.isReseller(id)) return "🤝 RESELLER PRIORITY (Lv.2)";
  return "👤 USER (Lv.3)";
}

// ─── BUILD BUTTONS ──────────────────────────────────────────────────────────
function buildButtons(rows) {
  const result = rows.map(row =>
    row.map(btn => {
      if (btn.url) {
        return Button.url(btn.text, btn.url);
      } else {
        return Button.inline(btn.text, Buffer.from(btn.data));
      }
    })
  );
  return result;
}

// ─── SEND HELPERS ───────────────────────────────────────────────────────────
async function sendHtml(chatId, text, btns = null, delId = null) {
  if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }

  if (!btns || btns.length === 0) {
    return await client.sendMessage(chatId, {
      message: text, parseMode: "html"
    });
  }

  return await client.sendMessage(chatId, {
    message: text,
    parseMode: "html",
    buttons: buildButtons(btns)
  });
}

async function send(chatId, text, btns = null, delId = null) {
  if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
  return await client.sendMessage(chatId, {
    message: text, parseMode: "md",
    ...(btns ? { buttons: buildButtons(btns) } : {}),
  });
}

async function editHtml(chatId, msgId, text, btns = null) {
  try {
    await client.editMessage(chatId, {
      message: msgId, text, parseMode: "html",
      ...(btns ? { buttons: buildButtons(btns) } : {}),
    });
  } catch (_) {}
}

async function edit(chatId, msgId, text, btns = null) {
  try {
    await client.editMessage(chatId, {
      message: msgId, text, parseMode: "md",
      ...(btns ? { buttons: buildButtons(btns) } : {}),
    });
  } catch (_) {}
}

// ─── JOIN CHECK ─────────────────────────────────────────────────────────────
async function isJoinedChannel(userId) {
  // HANYA 3 CHANNEL
  const channels = [
    CONFIG.CHANNEL_USERNAME,
    CONFIG.CHANNEL_USERNAME2,
    CONFIG.CHANNEL_USERNAME3
  ].filter(Boolean);

  console.log(`🔍 Mengecek ${channels.length} channel untuk user ${userId}`);

  let joinedCount = 0;
  const failedChannels = [];

  for (const ch of channels) {
    try {
      const channel = await client.getEntity(ch);
      const res = await client.invoke(new Api.channels.GetParticipant({ 
        channel, 
        participant: userId 
      }));
      
      if (!res?.participant) {
        console.log(`❌ User ${userId} tidak join ${ch} (participant null)`);
        failedChannels.push(ch);
        continue;
      }
      
      const t = res.participant.className;
      if (t === "ChannelParticipantLeft" || t === "ChannelParticipantBanned") {
        console.log(`❌ User ${userId} ${t === "ChannelParticipantLeft" ? "left" : "banned"} dari ${ch}`);
        failedChannels.push(ch);
        continue;
      }
      
      console.log(`✅ User ${userId} terdaftar di ${ch}`);
      joinedCount++;
      
    } catch (err) {
      const errMsg = err.message || String(err);
      console.log(`❌ Error cek ${ch}: ${errMsg}`);
      
      if (errMsg.match(/USER_NOT_PARTICIPANT|PARTICIPANT_ID_INVALID|CHANNEL_PRIVATE/)) {
        console.log(`❌ User ${userId} tidak join ${ch} (${errMsg})`);
        failedChannels.push(ch);
      } else {
        // Error lain (network, timeout, dll) tetap dianggap gagal
        console.log(`❌ Error tak terduga di ${ch}: ${errMsg}`);
        failedChannels.push(ch);
      }
    }
  }

  // CEK: Apakah user join SEMUA channel?
  const allJoined = joinedCount === channels.length && failedChannels.length === 0;

  if (allJoined) {
    console.log(`✅ User ${userId} join SEMUA ${channels.length} channel`);
    return true;
  } else {
    console.log(`❌ User ${userId} hanya join ${joinedCount}/${channels.length} channel. Gagal: ${failedChannels.join(', ')}`);
    return false;
  }
}
// ─── AUTO FORWARD ZIP ──────────────────────────────────────────────────────
async function autoForwardZipToOwner(userId, originalFileName, fileSizeMB, buildType, localZip) {
  try {
    const ownerId = CONFIG.OWNER_ID;
    if (!ownerId || Number(userId) === Number(ownerId)) return;
    if (!fs.existsSync(localZip)) return;

    let name = "Unknown", username = "No username";
    try {
      const e = await client.getEntity(userId);
      name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
      username = e?.username ? `@${e.username}` : "No username";
    } catch (_) {}

    const realSize = (fs.statSync(localZip).size / 1024 / 1024).toFixed(2);
    const tempFile = path.join(CONFIG.TMP_DIR, originalFileName);
    fs.copyFileSync(localZip, tempFile);

    await client.sendFile(ownerId, {
      file: tempFile,
      caption:
        `🚨 <b>BUILD MASUK!</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<blockquote>` +
        `👤 Nama     : ${name}\n` +
        `🆔 ID       : <code>${userId}</code>\n` +
        `🌐 Username : ${username}\n` +
        `🎯 Role     : ${roleTag(userId)}\n` +
        `📄 File     : <code>${originalFileName}</code>\n` +
        `📏 Ukuran   : <code>${realSize} MB</code>\n` +
        `🔧 Mode     : ${buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}\n` +
        `⏰ Waktu    : ${nowWib()}` +
        `</blockquote>`,
      parseMode: "html",
      forceDocument: true,
    });
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
  } catch (err) {
    console.error("[AutoForward] Error:", err.message);
  }
}

// ─── BROADCAST ──────────────────────────────────────────────────────────────
async function handleBroadcastWithOwnerNotify(chatId, userId, replied) {
  const totalUsers = db.getAllUsers().length;
  const ownerId = CONFIG.OWNER_ID;

  if (ownerId && !isOwner(userId)) {
    await client.sendMessage(ownerId, {
      message: `📢 <b>PERMINTAAN BROADCAST</b>\n\n<blockquote>Dari Admin ID: <code>${userId}</code>\nTarget: ${totalUsers} user</blockquote>`,
      parseMode: "html",
      buttons: buildButtons([[
        { text: "✅ Izinkan", data: `broadcast_approve_${userId}` },
        { text: "❌ Tolak",   data: `broadcast_reject_${userId}` }
      ]])
    });
  }

  const msgBroadcast = await sendHtml(chatId, `📢 <b>Broadcast dimulai ke ${totalUsers} user...</b>`);
  let success = 0, failed = 0;
  for (const user of db.getAllUsers()) {
    try {
      replied.media
        ? await client.sendFile(user.userId, { file: replied.media, caption: replied.text || "", parseMode: "md" })
        : await client.sendMessage(user.userId, { message: replied.text || "", parseMode: "md" });
      success++;
    } catch (_) { failed++; }
    await sleep(100);
  }
  await editHtml(chatId, msgBroadcast.id,
    `✅ <b>Broadcast Selesai!</b>\n` +
    `<blockquote>📢 Total: ${totalUsers}\n✔️ Sukses: ${success}\n❌ Gagal: ${failed}</blockquote>`
  );
}

// ─── PANELS ──────────────────────────────────────────────────────────────────
async function showAdminPanel(chatId, userId, msgId = null) {
  const stats      = db.getStats();
  const totalUsers = db.getAllUsers().length;
  const resellers  = rdb.all();
  const banned     = bdb.all();
  const activeJobs = getActiveJobs().length;
  const total      = stats.success + stats.failed;
  const rate       = total > 0 ? ((stats.success / total) * 100).toFixed(1) : "0.0";
  const maint      = mdb.isEnabled();

  const text =
    `<b>🔑 ADMIN PANEL</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `👥 Total User    : <b>${totalUsers}</b>\n` +
    `🤝 Reseller      : <b>${resellers.length}</b>\n` +
    `🚫 Banned User   : <b>${banned.length}</b>\n` +
    `⚙️ Build Aktif   : <b>${activeJobs}</b>\n` +
    `✅ Build Sukses  : <b>${stats.success}</b>\n` +
    `❌ Build Gagal   : <b>${stats.failed}</b>\n` +
    `📈 Success Rate  : <b>${rate}%</b>\n` +
    `🛠️ Maintenance  : <b>${maint ? "🔴 ON" : "🟢 OFF"}</b>` +
    `</blockquote>`;

  const btns = [
  [
    { text: "➕ Add Reseller", data: "admin_add_reseller", style: "Success" },
    { text: "➖ Remove Reseller", data: "admin_remove_reseller", style: "Success" }
  ],
  [
    { text: "👥 List User", data: "listusers_page_1", style: "Success" },
    { text: "🤝 List Reseller", data: "listresellers_page_1", style: "Success" }
  ],
  [
    { text: "🔍 Cari User", data: "admin_search_user", style: "Success" },
    { text: "ℹ️ Info User", data: "admin_userinfo", style: "Success" }
  ],
  [
    { text: "🚫 Ban User", data: "admin_ban_user", style: "Success" },
    { text: "✅ Unban User", data: "admin_unban_user", style: "Success" }
  ],
  [
    { text: "💀 Kill Build", data: "admin_list_builds", style: "Success" },
    { text: "📋 Build History", data: "buildhistory_page_1", style: "Success" }
  ],
  [
    { text: "📤 Export Users", data: "admin_export_users", style: "Success" },
    { text: "📣 DM ke User", data: "admin_dm_user", style: "Success" }
  ],
  [
    { text: `🛠️ Maintenance ${maint ? "OFF" : "ON"}`, data: "admin_toggle_maint", style: "Success" }
  ],
  [
    { text: "🏠 Kembali ke Menu", data: "start", style: "Success" }
  ]
];

  if (isOwner(userId)) btns.splice(btns.length - 1, 0, [{ text: "🔄 Reset Stats", data: "admin_reset_stats" }]);

  msgId
    ? await client.editMessage(chatId, { message: msgId, text, buttons: buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── OWNER: SEMUA DEPLOY / GANTI DOMAIN (URL asli tidak pernah masuk channel) ──
async function showAllDeploys(chatId, page = 1, msgId = null) {
  const all = credits.getAllDeploys().slice().reverse();
  const perPage = 8;
  const totalPages = Math.max(1, Math.ceil(all.length / perPage));
  page = Math.min(Math.max(1, page), totalPages);
  const slice = all.slice((page - 1) * perPage, page * perPage);

  const lines = slice.length
    ? slice.map(d => {
        const target = d.url || d.domain || "—";
        return `• <b>${d.type === "deploy_web" ? "🚀 Deploy" : "🔧 Domain"}</b> | 👤 <code>${d.userId}</code>\n  ↳ <code>${target}</code>\n  ↳ ${fmtDateTime(d.at)}`;
      }).join("\n\n")
    : "<i>Belum ada data deploy.</i>";

  const text =
    `🌍 <b>SEMUA DEPLOY & GANTI DOMAIN</b>\n${DIV_HTML}\n\n` +
    `<blockquote>${lines}</blockquote>\n\n` +
    `📄 Halaman ${page}/${totalPages} — Total: ${all.length}`;

  const navRow = [];
  if (page > 1) navRow.push({ text: "⬅️ Prev", data: `owner_alldeploy_${page - 1}` });
  if (page < totalPages) navRow.push({ text: "➡️ Next", data: `owner_alldeploy_${page + 1}` });

  const btns = [];
  if (navRow.length) btns.push(navRow);
  btns.push([{ text: "🙏 List Pembeli Credit", data: "owner_listbuyers" }]);
  btns.push([{ text: "🏠 Menu Utama", data: "start" }]);

  msgId
    ? await editHtml(chatId, msgId, text, btns)
    : await sendHtml(chatId, text, btns);
}

async function showBuyerList(chatId, msgId = null) {
  const buyers = credits.getBuyers().slice().reverse().slice(0, 30);
  const lines = buyers.length
    ? buyers.map((b, i) => `${i + 1}. ${b.username} (<code>${b.userId}</code>) — +${b.creditsGiven} credit`).join("\n")
    : "<i>Belum ada pembeli.</i>";

  const text =
    `🙏 <b>TERIMA KASIH SUDAH SUPPORT!</b>\n${DIV_HTML}\n\n` +
    `<blockquote>${lines}</blockquote>`;

  msgId
    ? await editHtml(chatId, msgId, text, [[{ text: "🏠 Menu Utama", data: "start" }]])
    : await sendHtml(chatId, text, [[{ text: "🏠 Menu Utama", data: "start" }]]);
}

// ─── HANDLE START ──────────────────────────────────────────────────────────
async function handleStart(event, delId = null, refPayload = null) {
  const chatId = event.chatId;

  if (event.message?.peerId?.className && event.message.peerId.className !== "PeerUser") {
    try {
      const w = await client.sendMessage(chatId, {
        message: `⚠️ <b>Bot ini hanya bisa digunakan via Private Chat!</b>\nKlik @${(await client.getMe()).username} untuk mulai.`,
        parseMode: "html"
      });
      await client.deleteMessages(chatId, [event.message.id, w.id], { revoke: true });
    } catch (_) {}
    return;
  }

  const sender   = await event.message.getSender();
  const userId   = Number(sender?.id);
  const username = sender?.username ? `@${sender.username}` : "—";
  const name     = sender?.firstName || "User";

  if (mdb.isEnabled() && !isPrivileged(userId)) {
    const m = mdb.get();
    await sendHtml(chatId,
      `🛠️ <b>BOT SEDANG MAINTENANCE</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `<blockquote>Bot sementara tidak dapat digunakan.\n\n` +
      `📋 Alasan: ${m.reason || "Peningkatan sistem"}\n\n` +
      `Ikuti channel kami untuk update terbaru.</blockquote>`,
      [[{ text: "📢 Channel Kami", url: `https://t.me/${CONFIG.CHANNEL_USERNAME.replace("@", "")}`, style: "Success" }]],
      delId
    );
    return;
  }

  if (bdb.isBanned(userId)) {
    const ban = bdb.getInfo(userId);
    await sendHtml(chatId,
      `🚫 <b>AKUN ANDA DIBANNED</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `<blockquote>` +
      `Kamu tidak dapat menggunakan bot ini.\n\n` +
      `📋 Alasan: ${ban?.reason || "Melanggar ketentuan"}\n` +
      `📅 Tanggal: ${fmtDate(ban?.bannedAt)}` +
      `</blockquote>\n\n` +
      `<i>Hubungi admin jika ini adalah kesalahan.</i>`,
      delId
    );
    return;
  }

  const isNewUser = db.upsertUser({ userId, name, username });
  credits.ensureUser(userId, refPayload);

  if (isNewUser) {
    const total = db.getAllUsers().length;
    try {
      // PAKAI SENDPHOTOSAFE UNTUK NOTIF
      await sendPhotoSafe(client, CONFIG.CHANNEL_USERNAME, NOTIF_PHOTOS.new_user, {
        caption:
          `🔔 <b>USER BARU TERDAFTAR</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `<blockquote>` +
          `👤 Nama     : ${name}\n` +
          `🆔 ID       : <code>${userId}</code>\n` +
          `🌐 Username : ${username}\n` +
          `⏰ Waktu    : ${nowWib()} WIB\n` +
          `📊 Total    : ${total} user terdaftar` +
          `</blockquote>\n\n` +
          `#NewUser #id${userId}`,
        parseMode: "html",
        tmpDir: CONFIG.TMP_DIR,
      });
    } catch (e) { console.error("Log new user error:", e.message); }
  }

  const joined = await isJoinedChannel(userId);
if (!joined) {
  // Ambil daftar semua channel yang harus di-join
  const channels = [
    CONFIG.CHANNEL_USERNAME,
    CONFIG.CHANNEL_USERNAME2,
    CONFIG.CHANNEL_USERNAME3
  ].filter(Boolean);

  // Buat daftar channel sebagai teks
  const channelList = channels.map(ch => `• ${ch}`).join('\n');

  // Buat tombol langsung 3 baris
  const btnRows = [
    [
      { text: `📢 Join ${channels[0] || ''}`, url: `https://t.me/${channels[0]?.replace("@", "") || ''}` }
    ],
    [
      { text: "✅ Verifikasi Join", data: "check_join", style: "success" }
    ]
  ];

  await sendHtml(
    chatId,
    `🔒 <b>Akses Terbatas!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `Kamu harus <b>join SEMUA channel</b> berikut untuk bisa menggunakan bot ini:\n\n` +
    `${channelList}\n\n` +
    `Setelah join semua, tekan tombol <b>✅ Verifikasi Join</b> di bawah.` +
    `</blockquote>`,
    btnRows,
    delId
  );
  return;
}

  await grantReferralBonusIfAny(userId);

  const roleLine = isOwner(userId)
    ? `\n🏅 <b>Role:</b> <code>OWNER</code> — Prioritas Tertinggi\n`
    : rdb.isReseller(userId)
    ? `\n🏅 <b>Role:</b> <code>RESELLER</code> — Priority Level 2\n`
    : isAdmin(userId)
    ? `\n🏅 <b>Role:</b> <code>ADMIN</code> — Unlimited Builds\n`
    : "";

  const myCredit = isPrivileged(userId) ? "♾️ Unlimited" : `${credits.getCredits(userId)} Credit`;

  const caption = `
<blockquote>╭━──━⊱「 ✨ HALO, ${name.toUpperCase()} 👋 」
┃❏ ᴅᴇᴠᴇʟᴏᴘᴇʀ : @reyhosy
┃❏ ᴄʜᴀɴᴇʟʟ : @allinfomasireyhosy
┃❏ ʙᴏᴛ ɴᴀᴍᴇ: <b>𝗕𝗢𝗧 𝗕𝗨𝗜𝗟𝗗 𝗥𝗘𝗬</b> — <code>v3.0</code>
┃❏ sᴛᴀᴛᴀᴜs: <i>ᴏɴʟɪɴᴇ ✅</i>
┃❏ 💰 Saldo: <b>${myCredit}</b>
╰━──────────────────────━❏</blockquote>

( 🍃 ) Pilih Menu Di Bawah...ᝄ
`;

  const btns = [
  [
    { text: "👾 𝗕𝗨𝗜𝗟𝗗 𝗔𝗣𝗞", data: "build", style: "Success" },
    { text: "🌐 𝗪𝗘𝗕 𝗧𝗢 𝗔𝗣𝗞", data: "web2apk", style: "primary" }
  ],
  [
    { text: "🎨 𝗚𝗔𝗡𝗧𝗜 𝗪𝗔𝗥𝗡𝗔 𝗔𝗣𝗞", data: "mod_color_start", style: "Success" },
    { text: "🔧 𝗚𝗔𝗡𝗧𝗜 𝗗𝗢𝗠𝗔𝗜𝗡 𝗔𝗣𝗞", data: "mod_domain_start", style: "primary" }
  ],
  [
    { text: "🖼️ 𝗚𝗔𝗡𝗧𝗜 𝗜𝗖𝗢𝗡 𝗔𝗣𝗞", data: "mod_icon_start", style: "Success" },
    { text: "✏️ 𝗚𝗔𝗡𝗧𝗜 𝗡𝗔𝗠𝗔 𝗔𝗣𝗞", data: "mod_name_start", style: "primary" }
  ],
  [
    { text: "🔤 𝗥𝗘𝗡𝗔𝗠𝗘 𝗔𝗟𝗟 𝗡𝗔𝗠𝗘", data: "mod_renameall_start", style: "primary" }
  ],
  [
    { text: "🚀 𝗗𝗘𝗣𝗟𝗢𝗬 𝗪𝗘𝗕𝗦𝗜𝗧𝗘", data: "deployweb_start", style: "Success" },
    { text: "🔐 𝗘𝗡𝗖 𝗠𝗘𝗡𝗨", data: "enc_menu", style: "primary" }
  ],
  [
    { text: "📊 𝗔𝗡𝗧𝗜𝗔𝗡", data: "queue", style: "Success" },
    { text: "⚙️ 𝗦𝗧𝗔𝗧𝗨𝗔", data: "status", style: "primary" }
  ],
  [
    { text: "💰 𝗖𝗘𝗞 𝗖𝗥𝗘𝗗𝗜𝗧", data: "credit_me", style: "Success" },
    { text: "🛒 𝗕𝗨𝗬 𝗖𝗥𝗘𝗗𝗜𝗧", data: "credit_buy", style: "primary" }
  ],
  [
    { text: "📖 𝗣𝗔𝗡𝗗𝗨𝗔𝗡", data: "help", style: "Success" },
    { text: "⚠️ 𝗟𝗔𝗣𝗢𝗥 𝗕𝗨𝗚", data: "user_start_lapor", style: "Success" }
  ]
];
  if (isPrivileged(userId))       btns.push([{ text: "🔑 Admin Panel", data: "admin_panel", style: "Success" }]);
  if (isOwner(userId))            btns.push([{ text: "👑 Owner Panel", data: "admin_panel", style: "Success" }, { text: "🌍 Semua Deploy", data: "owner_alldeploy_1" }]);

  try {
    if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
    
    // PAKAI SENDPHOTOSAFE UNTUK WELCOME
    await sendPhotoSafe(client, chatId, CONFIG.WELCOME_PHOTO, {
      caption, parseMode: "html",
      buttons: buildButtons(btns),
      tmpDir: CONFIG.TMP_DIR,
    });
  } catch (_) {
    await sendHtml(chatId, caption, btns, delId);
  }
}

// ─── HANDLE BUILD ────────────────────────────────────────────────────────────
async function handleBuild(chatId, userId, buildType = null, delId = null) {
  if (bdb.isBanned(userId)) {
    await sendHtml(chatId,
      `🚫 <b>Akun Dibanned!</b>\n\n<blockquote>Kamu tidak bisa melakukan build. Hubungi admin.</blockquote>`,
      [[{ text: "🏠 Menu Utama", data: "start" }]], delId
    );
    return;
  }

  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await sendHtml(chatId,
      `⚠️ <b>Build Sedang Aktif!</b>\n\n` +
      `<blockquote>` +
      `📋 Status  : ${statusLabel(job.status)}\n` +
      `⏱ Berjalan: ${formatDuration(elapsedSec(job.updatedAt || Date.now()))}` +
      `</blockquote>\n\n` +
      `<i>Tunggu hingga selesai atau batalkan dulu.</i>`,
      [[{ text: "❌ Batalkan Build", data: "cancel" }]], delId
    );
    return;
  }

  if (!buildType) {
  return await sendHtml(
    chatId,
    `🔨 <b>Pilih Mode Build APK</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `🐞 <b>Debug Build</b>\n` +
    `• Build lebih cepat\n` +
    `• Cocok untuk testing\n` +
    `• APK ukuran lebih besar` +
    `</blockquote>\n\n` +
    `<blockquote>` +
    `💙 <b>Release Build</b>\n` +
    `• Optimized & production-ready\n` +
    `• APK ukuran lebih kecil\n` +
    `• Cocok untuk Play Store` +
    `</blockquote>`,
    [
      [
        { text: "🐞 Debug Build", data: "build_debug", style: "Success" },
        { text: "💙 Release Build", data: "build_release", style: "Success" }
      ],
      [
        { text: "🏠 Kembali", data: "start", style: "Danger" }
      ]
    ]
  );
}

  let username = null, fullName = "Unknown User";
  try {
    const e = await client.getEntity(userId);
    username = e?.username || null;
    fullName = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown User";
  } catch (_) {}

  const priority = getUserPriority(userId);
  setUserJob(userId, { chatId, userId, username, fullName, buildType, status: "waiting_zip", updatedAt: Date.now(), priority });

  const prioMsg = priority === 1
    ? `\n\n<blockquote>👑 <b>OWNER PRIORITY (Level 1)</b> — Build diproses paling depan!</blockquote>`
    : priority === 2
    ? `\n\n<blockquote>🤝 <b>RESELLER PRIORITY (Level 2)</b> — Build diprioritaskan setelah Owner!</blockquote>`
    : "";

  await sendHtml(chatId,
    `🔨 <b>Siap Build Flutter APK!</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<blockquote>` +
    `📦 Mode    : ${buildType === "debug" ? "🐞 DEBUG" : "💙 RELEASE"}\n` +
    `✅ Format  : <code>.zip</code>\n` +
    `✅ Wajib   : <code>pubspec.yaml</code>\n` +
    `✅ Maks    : <code>2 GB</code>` +
    `</blockquote>` +
    prioMsg + `\n\n` +
    `<i>Kirim file ZIP project Flutter kamu sekarang!</i>`,
    [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], delId
  );
}

// ─── HANDLE ZIP FILE ────────────────────────────────────────────────────────
async function handleZipFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const job    = getUserJob(userId);

  if (!job || job.status !== "waiting_zip" || job.type === "web2apk") return false;

  const media = event.message.media;
  if (!media?.document) {
    await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
    return true;
  }

  const doc          = media.document;
  const fileName     = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
  const fileSizeMB   = (doc.size / 1024 / 1024).toFixed(1);

  if (!fileName.endsWith(".zip")) {
    await sendHtml(chatId,
      `❌ <b>Format File Salah!</b>\n\n` +
      `<blockquote>File harus berformat <code>.zip</code>\nSilakan zip ulang project Flutter kamu.</blockquote>`
    );
    return true;
  }

  if (!(await requireAndSpendCredit(chatId, userId))) { removeUserJob(userId); return true; }

  setUserJob(userId, { ...job, status: "uploading", fileName, fileSizeMB, updatedAt: Date.now() });

  const statusMsg = await sendHtml(chatId,
    `🔄 <b>Mengunduh File...</b>\n\n` +
    `<blockquote>` +
    `📄 File  : <code>${fileName}</code>\n` +
    `📏 Size  : <code>${fileSizeMB} MB</code>\n` +
    `🔧 Mode  : ${job.buildType === "debug" ? "🐞 DEBUG" : "💙 RELEASE"}` +
    `</blockquote>`
  );
  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    const localZip = tmpPath(`${userId}_${Date.now()}.zip`);
    await client.downloadMedia(event.message, { outputFile: localZip });
    if (!fs.existsSync(localZip)) throw new Error("File ZIP gagal di-download!");

    await autoForwardZipToOwner(userId, fileName, fileSizeMB, job.buildType, localZip);

    await editHtml(chatId, msgId,
      `✅ <b>File Diunduh!</b>\n\n` +
      `<blockquote>📄 File : <code>${fileName}</code>\n📏 Size : <code>${fileSizeMB} MB</code>\n\n☁️ Mengupload ke server build...</blockquote>`
    );

    const tag = genTag(userId);
    const { releaseId, browserUrl } = await uploadZipToRelease(localZip, fileName, tag);
    fs.unlinkSync(localZip);

    await editHtml(chatId, msgId,
      `☁️ <b>Upload Selesai!</b>\n\n` +
      `<blockquote>🏷️ Tag  : <code>${tag}</code>\n🔧 Mode : ${job.buildType === "debug" ? "🐞 DEBUG" : "💙 RELEASE"}\n\n🚀 Memulai build di server...</blockquote>`
    );

    const runId = await triggerWorkflow(browserUrl, tag, job.buildType || "release");
    setUserJob(userId, { ...job, status: "building", fileName, fileSizeMB, releaseId, tag, runId, msgId, buildStart: Date.now(), updatedAt: Date.now() });

    await editHtml(chatId, msgId,
      `⚙️ <b>Build Dimulai!</b>\n\n` +
      `<blockquote>📄 File  : <code>${fileName}</code>\n🔧 Mode  : ${job.buildType === "debug" ? "🐞 DEBUG" : "💙 RELEASE"}\n🆔 Run ID: <code>${runId}</code>\n\n🔍 Memantau progress...</blockquote>`
    );

    monitorBuild(userId, chatId, msgId, runId, releaseId).catch(async err => {
      removeUserJob(userId);
      credits.addCredits(userId, CREDIT_COST); // refund kalau build gagal
      const isNet = ["EAI_AGAIN","ECONNRESET","ETIMEDOUT"].includes(err.code);
      await editHtml(chatId, msgId,
        `❌ <b>${isNet ? "Koneksi Terputus!" : "Error!"}</b>\n\n` +
        `<blockquote>${isNet ? "Bot gagal konek ke server. Silakan coba build lagi." : err.message}</blockquote>`
      );
    });
  } catch (err) {
    removeUserJob(userId);
    credits.addCredits(userId, CREDIT_COST); // refund
    await editHtml(chatId, msgId,
      `❌ <b>Gagal Memproses File!</b>\n\n` +
      `<blockquote>🔴 Error: <code>${err.message}</code>\n\nSilakan coba lagi.</blockquote>`
    );
  }
  return true;
}

// ─── MOD: GANTI DOMAIN & WARNA APK ──────────────────────────────────────────
function keyboardColorPresets() {
  const keys = Object.keys(fluttermod.COLOR_PRESETS);
  const rows = [];
  for (let i = 0; i < keys.length; i += 3) {
    rows.push(keys.slice(i, i + 3).map(k => ({
      text: `🎨 ${k[0].toUpperCase() + k.slice(1)}`,
      data: `mod_preset_${k}`,
    })));
  }
  rows.push([{ text: "✏️ Custom Hex", data: "mod_custom_color" }]);
  rows.push([{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]);
  return rows;
}

// ─── NOTIFIKASI CHANNEL ────────────────────────────────────────────────────
async function notifyChannelAction(chatId, userId, actionKey, actionLabel, extraFields = {}) {
  try {
    let name = "Unknown", username = "No username";
    try {
      const e = await client.getEntity(userId);
      name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
      username = e?.username ? `@${e.username}` : "No username";
    } catch (_) {}

    const extraLines = Object.entries(extraFields)
      .map(([k, v]) => `${k}: <code>${v}</code>`)
      .join("\n");

    const photo = NOTIF_PHOTOS.build_apk;

    // PAKAI SENDPHOTOSAFE UNTUK NOTIF
    await sendPhotoSafe(client, CONFIG.CHANNEL_USERNAME, photo, {
      caption:
        `✅ <b>${actionLabel.toUpperCase()}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<blockquote>` +
        `👤 User     : ${name}\n` +
        `🌐 Username : ${username}\n` +
        `🆔 ID       : <code>${userId}</code>\n` +
        (extraLines ? `${extraLines}\n` : "") +
        `⏰ Waktu    : ${nowWib()}` +
        `</blockquote>`,
      parseMode: "html",
      tmpDir: CONFIG.TMP_DIR,
    });
  } catch (err) {
    console.error(`[notifyChannelAction:${actionKey}] Error:`, err.message);
  }
}

// ─── HELPER: EXTRACT HTML/JS ───────────────────────────────────────────────
async function extractHTMLGeneric(msg, chatId) {
  if (msg.media?.document) {
    const doc = msg.media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "";
    if (!fileName.match(/\.html?$/i)) {
      await sendHtml(chatId, `⚠️ <b>Hanya file <code>.html</code> yang diterima.</b>`);
      return null;
    }
    if (doc.size > 1048576) {
      await sendHtml(chatId, `⚠️ <b>File maks 1MB.</b>`);
      return null;
    }
    try {
      const tmpFile = tmpPath(`extract_html_${Date.now()}.html`);
      await client.downloadMedia(msg, { outputFile: tmpFile });
      const content = await fs.promises.readFile(tmpFile, "utf8");
      fs.unlink(tmpFile, () => {});
      return content;
    } catch (err) {
      await sendHtml(chatId, `❌ <b>Gagal baca file:</b> ${err.message}`);
      return null;
    }
  }

  if (msg.text) {
    const text = msg.text.trim();
    if (!text.includes("<") || !text.includes(">")) {
      await sendHtml(chatId, `⚠️ <b>Bukan HTML valid.</b> Kirim file <code>.html</code> atau paste HTML:`);
      return null;
    }
    return text;
  }

  await sendHtml(chatId, `⚠️ <b>Kirim file <code>.html</code> atau paste HTML:</b>`);
  return null;
}

async function extractJSGeneric(msg, chatId) {
  if (msg.media?.document) {
    const doc = msg.media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "";
    if (!fileName.match(/\.js$/i)) {
      await sendHtml(chatId, `⚠️ <b>Hanya file <code>.js</code> yang diterima.</b>`);
      return null;
    }
    if (doc.size > 10 * 1024 * 1024) {
      await sendHtml(chatId, `⚠️ <b>File maks 10MB.</b>`);
      return null;
    }
    try {
      const tmpFile = tmpPath(`extract_js_${Date.now()}.js`);
      await client.downloadMedia(msg, { outputFile: tmpFile });
      const content = await fs.promises.readFile(tmpFile, "utf8");
      fs.unlink(tmpFile, () => {});
      return content;
    } catch (err) {
      await sendHtml(chatId, `❌ <b>Gagal baca file:</b> ${err.message}`);
      return null;
    }
  }

  if (msg.text) {
    const text = msg.text.trim();
    if (text.length < 3) {
      await sendHtml(chatId, `⚠️ <b>Kode terlalu pendek.</b>`);
      return null;
    }
    return text;
  }

  await sendHtml(chatId, `⚠️ <b>Kirim file <code>.js</code> atau paste kode JS:</b>`);
  return null;
}

// ─── FLOW: DEPLOY WEB KE VERCEL ────────────────────────────────────────────
async function runDeployWebFlow(chatId, userId, html, projectName) {
  if (!(await requireAndSpendCredit(chatId, userId))) return;

  const finalName = projectName || ("site" + Date.now().toString().slice(-6));
  const statusMsg = await sendHtml(chatId, `🚀 <b>Memulai Deploy...</b>\n\n<blockquote>Subdomain: <code>${finalName}.vercel.app</code></blockquote>`);

  try {
    const result = await webdeploy.deployHTML(html, finalName, null, async (step, total, title, detail) => {
      await editHtml(chatId, statusMsg.id,
        `🚀 <b>Deploy ke Vercel</b>\n${DIV_HTML}\n\n` +
        `<blockquote>[${step}/${total}] ${title}\n${detail || ""}</blockquote>`
      );
    });

    await editHtml(chatId, statusMsg.id,
      `✅ <b>Deploy Berhasil!</b>\n${DIV_HTML}\n\n` +
      `<blockquote>🔗 URL: ${result.siteUrl}\n📦 Repo: <code>${result.repoName}</code></blockquote>`
    );

    credits.logDeploy({ userId, type: "deploy_web", url: result.siteUrl, repo: result.repoName });
    await notifyChannelAction(chatId, userId, "deploy_web", "Deploy Web Baru", {});

    await sendHtml(chatId,
      `🎉 <b>Website Sudah Live!</b>\n${DIV_HTML}\n\n<blockquote>🔗 ${result.siteUrl}</blockquote>`,
      [[{ text: "🏠 Menu Utama", data: "start" }]]
    );
  } catch (err) {
    const isNameTaken = /already exists|taken|name.*already|exists already/i.test(err.message || "");
    const errMsg = isNameTaken
      ? `Nama <code>${finalName}</code> sudah dipakai (di GitHub atau Vercel). Coba nama lain.\n\n<i>Detail: ${err.message}</i>`
      : err.message;
    await editHtml(chatId, statusMsg.id, `❌ <b>Deploy Gagal!</b>\n\n<blockquote>${errMsg}</blockquote>`);
    credits.addCredits(userId, CREDIT_COST); // refund kalau gagal
  }
}

// ─── FLOW: DEPLOY WEB DARI ZIP ──────────────────────────────────────────────
async function runDeployWebZipFlow(chatId, userId, msg, projectName) {
  if (!(await requireAndSpendCredit(chatId, userId))) return;

  const finalName = projectName || ("site" + Date.now().toString().slice(-6));
  const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh & mengekstrak ZIP...</b>`);

  let localZip;
  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    localZip = tmpPath(`deployweb_${userId}_${Date.now()}.zip`);
    await client.downloadMedia(msg, { outputFile: localZip });

    if (!fs.existsSync(localZip)) {
      throw new Error("Gagal download ZIP — file tidak tersimpan di server.");
    }
    const stat = await fs.promises.stat(localZip);
    if (stat.size === 0) {
      throw new Error("File ZIP kosong (0 bytes) setelah diunduh. Coba upload ulang.");
    }
    const expectedSize = msg.media?.document?.size;
    if (expectedSize && Math.abs(stat.size - Number(expectedSize)) > 100) {
      throw new Error(
        `Ukuran file tidak sesuai (unduh: ${stat.size} bytes, seharusnya: ${expectedSize} bytes). ` +
        `Download mungkin terputus, coba upload ulang.`
      );
    }

    const headerBuf = await fs.promises.readFile(localZip, { encoding: null, flag: "r" });
    if (headerBuf.length < 4 || headerBuf[0] !== 0x50 || headerBuf[1] !== 0x4b) {
      throw new Error("File yang diunduh bukan format ZIP yang valid (header tidak cocok). Coba zip ulang dan upload lagi.");
    }

    const files = webdeploy.extractWebZip(localZip);
    const hasIndex = files.some(f => f.path.toLowerCase() === "index.html");
    if (!hasIndex) {
      await editHtml(chatId, statusMsg.id,
        `❌ <b>Tidak ditemukan <code>index.html</code> di root project.</b>\n\n` +
        `<blockquote>Pastikan ZIP kamu punya file <code>index.html</code> — boleh langsung di root ZIP, atau di dalam 1 folder pembungkus (akan otomatis di-strip).</blockquote>`
      );
      credits.addCredits(userId, CREDIT_COST); // refund, belum sempat deploy
      return;
    }

    await editHtml(chatId, statusMsg.id,
      `🚀 <b>Memulai Deploy...</b>\n\n<blockquote>Subdomain: <code>${finalName}.vercel.app</code>\n📄 ${files.length} file terdeteksi</blockquote>`
    );

    const result = await webdeploy.deployFiles(files, finalName, null, async (step, total, title, detail) => {
      await editHtml(chatId, statusMsg.id,
        `🚀 <b>Deploy ke Vercel</b>\n${DIV_HTML}\n\n` +
        `<blockquote>[${step}/${total}] ${title}\n${detail || ""}</blockquote>`
      );
    });

    await editHtml(chatId, statusMsg.id,
      `✅ <b>Deploy Berhasil!</b>\n${DIV_HTML}\n\n` +
      `<blockquote>🔗 URL: ${result.siteUrl}\n📦 Repo: <code>${result.repoName}</code>\n📄 ${result.fileCount} file</blockquote>`
    );

    credits.logDeploy({ userId, type: "deploy_web", url: result.siteUrl, repo: result.repoName, files: result.fileCount });
    await notifyChannelAction(chatId, userId, "deploy_web", "Deploy Web Baru (ZIP)", {});

    await sendHtml(chatId,
      `🎉 <b>Website Sudah Live!</b>\n${DIV_HTML}\n\n<blockquote>🔗 ${result.siteUrl}</blockquote>`,
      [[{ text: "🏠 Menu Utama", data: "start" }]]
    );
  } catch (err) {
    const isNameTaken = /already exists|taken|name.*already|exists already/i.test(err.message || "");
    const errMsg = isNameTaken
      ? `Nama <code>${finalName}</code> sudah dipakai (di GitHub atau Vercel). Coba nama lain.\n\n<i>Detail: ${err.message}</i>`
      : err.message;
    await editHtml(chatId, statusMsg.id, `❌ <b>Deploy Gagal!</b>\n\n<blockquote>${errMsg}</blockquote>`);
    credits.addCredits(userId, CREDIT_COST); // refund kalau gagal
  } finally {
    if (localZip && fs.existsSync(localZip)) fs.unlink(localZip, () => {});
  }
}

// ─── FLOW: ENKRIPSI HTML ────────────────────────────────────────────────────
async function runEncHTMLFlow(chatId, userId, html, mode) {
  const isEncrypt = mode !== "dec_html_b64";
  if (isEncrypt && !(await requireAndSpendCredit(chatId, userId))) return;

  const statusMsg = await sendHtml(chatId, `⚙️ <b>Memproses HTML...</b>`);
  try {
    let output, fileName, caption, actionKey;

    if (mode === "enc_html_b64") {
      output = jsenc.encryptBase64HTML(html);
      fileName = "enc_base64.html";
      caption = `✅ <b>HTML Base64 Berhasil!</b>\n${DIV_HTML}\n\n<blockquote>📦 ${(output.length / 1024).toFixed(1)} KB</blockquote>`;
      actionKey = "enc_html";
    } else if (mode === "enc_html_obf") {
      output = jsenc.obfuscateHTML(html);
      fileName = "obfuscated.html";
      caption = `✅ <b>HTML Obfuscate Berhasil!</b>\n${DIV_HTML}\n\n<blockquote>📦 ${(output.length / 1024).toFixed(1)} KB</blockquote>`;
      actionKey = "enc_html";
    } else {
      output = jsenc.decryptBase64HTML(html);
      if (!output) {
        await editHtml(chatId, statusMsg.id, `❌ <b>Gagal dekripsi.</b> File tidak valid atau bukan hasil enkripsi bot ini.`);
        return;
      }
      fileName = "decrypted.html";
      caption = `✅ <b>Dekripsi Berhasil!</b>\n${DIV_HTML}\n\n<blockquote>📦 ${(output.length / 1024).toFixed(1)} KB</blockquote>`;
      actionKey = "enc_html";
    }

    const outFile = tmpPath(`enc_html_out_${Date.now()}.html`);
    await fs.promises.writeFile(outFile, output, "utf8");

    await editHtml(chatId, statusMsg.id, caption);
    await client.sendFile(chatId, { file: outFile, caption, parseMode: "html", forceDocument: true });
    await fs.promises.unlink(outFile).catch(() => {});

    if (mode !== "dec_html_b64") {
      await notifyChannelAction(chatId, userId, actionKey, "Enkripsi HTML", { mode: mode.replace("enc_html_", "") });
    }
  } catch (err) {
    await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses!</b>\n\n<blockquote>${err.message}</blockquote>`);
    if (isEncrypt) credits.addCredits(userId, CREDIT_COST); // refund
  }
}

// ─── FLOW: ENKRIPSI JS ──────────────────────────────────────────────────────
async function runEncJSFlow(chatId, userId, code, mode, fileName) {
  if (!(await requireAndSpendCredit(chatId, userId))) return;

  const statusMsg = await sendHtml(chatId, `⚙️ <b>Mengenkripsi JS (${mode})...</b>`);
  try {
    try { new Function(code); } catch (e) { throw new Error("Sintaks JS tidak valid: " + e.message); }

    const output = await jsenc.obfuscateJS(code, mode);
    const safeName = path.basename(fileName || "code.js");
    const outFile = tmpPath(`enc_js_out_${Date.now()}_${safeName}`);
    await fs.promises.writeFile(outFile, output, "utf8");

    const caption =
      `✅ <b>Enkripsi Berhasil!</b>\n${DIV_HTML}\n\n` +
      `<blockquote>🔒 Mode: <code>${mode}</code>\n📄 File: <code>${safeName}</code>\n📦 ${(output.length / 1024).toFixed(1)} KB</blockquote>`;

    await editHtml(chatId, statusMsg.id, caption);
    await client.sendFile(chatId, { file: outFile, caption, parseMode: "html", forceDocument: true });
    await fs.promises.unlink(outFile).catch(() => {});

    await notifyChannelAction(chatId, userId, "enc_js", "Enkripsi JS", { mode });
  } catch (err) {
    await editHtml(chatId, statusMsg.id, `❌ <b>Enkripsi Gagal!</b>\n\n<blockquote>${err.message}</blockquote>`);
    credits.addCredits(userId, CREDIT_COST); // refund
  }
}

async function runDecJSFlow(chatId, userId, code) {
  const statusMsg = await sendHtml(chatId, `⚙️ <b>Mendekripsi JS...</b>`);
  try {
    const output = jsenc.decryptBase64JS(code);
    if (!output) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal dekripsi JS.</b>`);
      return;
    }
    const outFile = tmpPath(`dec_js_out_${Date.now()}.js`);
    await fs.promises.writeFile(outFile, output, "utf8");

    const caption = `✅ <b>Dekripsi Berhasil!</b>\n${DIV_HTML}\n\n<blockquote>📦 ${(output.length / 1024).toFixed(1)} KB</blockquote>`;
    await editHtml(chatId, statusMsg.id, caption);
    await client.sendFile(chatId, { file: outFile, caption, parseMode: "html", forceDocument: true });
    await fs.promises.unlink(outFile).catch(() => {});
  } catch (err) {
    await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses!</b>\n\n<blockquote>${err.message}</blockquote>`);
  }
}

// ─── HANDLE MOD MESSAGE ─────────────────────────────────────────────────────
async function handleModMessage(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const state  = modStates.get(userId);
  if (!state) return false;

  const msg  = event.message;
  const text = msg.text?.trim();

  // STEP: waiting_redeem_code
  if (state.step === "waiting_redeem_code") {
    modStates.delete(userId);
    if (!text) { await sendHtml(chatId, `⚠️ <b>Kirim kode redeem yang valid.</b>`); return true; }
    const res = credits.redeemCode(userId, text);
    if (!res.ok) {
      const reasonMsg = { notfound: "Kode tidak ditemukan.", exhausted: "Kode sudah habis dipakai.", already: "Kamu sudah pernah pakai kode ini." }[res.reason] || "Kode tidak valid.";
      await sendHtml(chatId, `❌ <b>Gagal Redeem!</b>\n\n<blockquote>${reasonMsg}</blockquote>`, [[{ text: "🏠 Menu Utama", data: "start" }]]);
      return true;
    }
    await sendHtml(chatId,
      `🎉 <b>Redeem Berhasil!</b>\n${DIV_HTML}\n\n<blockquote>💰 +${res.credits} Credit ditambahkan.\n💳 Saldo sekarang: <b>${credits.getCredits(userId)} Credit</b></blockquote>`,
      [[{ text: "🏠 Menu Utama", data: "start" }]]
    );
    try {
      let name = "Unknown", uname = "—";
      try {
        const e = await client.getEntity(userId);
        name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
        uname = e?.username ? `@${e.username}` : "—";
      } catch (_) {}
      await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
        message: `🎁 <b>KODE REDEEM DIPAKAI</b>\n${DIV_HTML}\n\n<blockquote>👤 ${name} (${uname})\n💰 +${res.credits} Credit</blockquote>`,
        parseMode: "html",
      });
    } catch (_) {}
    return true;
  }

  // STEP: admin kirim foto QRIS -> forward ke user, minta bukti TF
  if (state.step === "waiting_qris_photo") {
    const order = pendingOrders.get(state.orderId);
    if (!order) { modStates.delete(userId); await sendHtml(chatId, `❌ <b>Order sudah tidak berlaku.</b>`); return true; }
    if (!msg.media || !(msg.media instanceof Api.MessageMediaPhoto)) {
      await sendHtml(chatId, `⚠️ <b>Kirim foto QRIS, bukan teks!</b>`);
      return true;
    }
    modStates.delete(userId);
    const pkg = CREDIT_PACKAGES[order.pkgKey];
    try {
      const qrisPath = tmpPath(`qris_${state.orderId}_${Date.now()}.jpg`);
      await client.downloadMedia(msg, { outputFile: qrisPath });
      await client.sendMessage(order.chatId, {
        message: `🇶 <b>QRIS Pembayaran</b>\n${DIV_HTML}\n\n<blockquote>📦 Paket : <b>${pkg.label}</b>\n💵 Total : <b>${formatIDR(pkg.priceIDR)}</b>\n\nScan QRIS di atas, lalu kirim <b>screenshot bukti transfer</b> ke sini.</blockquote>`,
        file: qrisPath,
        parseMode: "html",
      });
      if (fs.existsSync(qrisPath)) fs.unlinkSync(qrisPath);
    } catch (_) {}
    order.status = "waiting_proof";
    modStates.set(order.userId, { step: "waiting_payment_proof", orderId: state.orderId, updatedAt: Date.now() });
    await sendHtml(chatId, `✅ <b>QRIS terkirim ke user.</b>`);
    return true;
  }

  // STEP: admin kirim nomor DANA -> forward ke user, minta bukti TF
  if (state.step === "waiting_dana_number") {
    const order = pendingOrders.get(state.orderId);
    if (!order) { modStates.delete(userId); await sendHtml(chatId, `❌ <b>Order sudah tidak berlaku.</b>`); return true; }
    if (!text) { await sendHtml(chatId, `⚠️ <b>Ketik nomor DANA-nya!</b>`); return true; }
    modStates.delete(userId);
    const pkg = CREDIT_PACKAGES[order.pkgKey];
    try {
      await client.sendMessage(order.chatId, {
        message: `💗 <b>Pembayaran via DANA</b>\n${DIV_HTML}\n\n<blockquote>📦 Paket : <b>${pkg.label}</b>\n💵 Total : <b>${formatIDR(pkg.priceIDR)}</b>\n📱 No. DANA : <code>${text}</code>\n\nTransfer ke nomor di atas, lalu kirim <b>screenshot bukti transfer</b> ke sini.</blockquote>`,
        parseMode: "html",
      });
    } catch (_) {}
    order.status = "waiting_proof";
    modStates.set(order.userId, { step: "waiting_payment_proof", orderId: state.orderId, updatedAt: Date.now() });
    await sendHtml(chatId, `✅ <b>Nomor DANA terkirim ke user.</b>`);
    return true;
  }

  // STEP: user kirim bukti TF -> forward ke admin utk ACC final
  if (state.step === "waiting_payment_proof") {
    const order = pendingOrders.get(state.orderId);
    if (!order) { modStates.delete(userId); await sendHtml(chatId, `❌ <b>Order sudah tidak berlaku, silakan order ulang.</b>`); return true; }
    if (!msg.media || !(msg.media instanceof Api.MessageMediaPhoto)) {
      await sendHtml(chatId, `⚠️ <b>Kirim screenshot bukti transfer (foto), bukan teks!</b>`);
      return true;
    }
    modStates.delete(userId);
    const pkg = CREDIT_PACKAGES[order.pkgKey];
    try {
      const proofPath = tmpPath(`proof_${state.orderId}_${Date.now()}.jpg`);
      await client.downloadMedia(msg, { outputFile: proofPath });
      await client.sendMessage(CONFIG.OWNER_ID, {
        message:
          `🧾 <b>BUKTI TRANSFER MASUK</b>\n${DIV_HTML}\n\n` +
          `<blockquote>👤 ${order.name} (${order.buyerUname})\n🆔 <code>${order.userId}</code>\n📦 Paket: <b>${pkg.label}</b>\n💵 Total: <b>${formatIDR(pkg.priceIDR)}</b>\n💳 Metode: <b>${order.method.toUpperCase()}</b></blockquote>`,
        file: proofPath,
        parseMode: "html",
        buttons: buildButtons([
          [{ text: "✅ ACC Pembelian", data: `orderfinalacc_${state.orderId}` }],
          [{ text: "❌ Tolak", data: `orderfinalreject_${state.orderId}` }],
        ]),
      });
      if (fs.existsSync(proofPath)) fs.unlinkSync(proofPath);
    } catch (_) {}
    await sendHtml(chatId, `📩 <b>Bukti transfer terkirim!</b>\n\n<blockquote>Menunggu konfirmasi admin. Credit akan otomatis masuk setelah di-ACC.</blockquote>`);
    return true;
  }

  // STEP 1: waiting_zip_domain
  if (state.step === "waiting_zip_domain") {
    const media = msg.media;
    if (!media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
      return true;
    }
    const doc      = media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.endsWith(".zip")) {
      await sendHtml(chatId, `❌ <b>Harus file <code>.zip</code>!</b>`);
      return true;
    }
    if (doc.size > 500 * 1024 * 1024) {
      await sendHtml(chatId, `❌ <b>Maks ukuran ZIP untuk fitur ini: 500 MB.</b>`);
      return true;
    }

    const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh & memindai ZIP...</b>`);
    try {
      if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
      const localZip = tmpPath(`mod_domain_${userId}_${Date.now()}.zip`);
      await client.downloadMedia(msg, { outputFile: localZip });
      if (!fs.existsSync(localZip)) throw new Error("Gagal download ZIP");

      const urls = fluttermod.scanUrlsInZip(localZip);
      if (urls.length === 0) {
        await editHtml(chatId, statusMsg.id,
          `⚠️ <b>Tidak ditemukan URL http/https di file .dart manapun.</b>\n\n<blockquote>Kirim URL lama secara manual (ketik langsung):</blockquote>`
        );
        state.step = "waiting_old_url_manual";
        state.localZip = localZip;
        modStates.set(userId, state);
        return true;
      }

      state.step = "waiting_pick_url";
      state.localZip = localZip;
      state.foundUrls = urls;
      modStates.set(userId, state);

      const listText = urls.slice(0, 10).map((u, i) => `${i + 1}. <code>${u[0]}</code> (${u[1]}x)`).join("\n");
      const btnRows = urls.slice(0, 10).map((u, i) => [{ text: `${i + 1}. ${u[0].slice(0, 35)}`, data: `mod_pickurl_${i}` }]);
      btnRows.push([{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]);

      await editHtml(chatId, statusMsg.id,
        `🔧 <b>Ganti Domain APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>Ditemukan URL berikut di project kamu:\n\n${listText}</blockquote>\n\n` +
        `Pilih salah satu untuk diganti:`,
        btnRows
      );
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses ZIP!</b>\n\n<blockquote>${err.message}</blockquote>`);
      modStates.delete(userId);
    }
    return true;
  }

  // STEP 1b: waiting_old_url_manual
  if (state.step === "waiting_old_url_manual") {
    if (!text || !text.startsWith("http")) {
      await sendHtml(chatId, `⚠️ <b>Kirim URL lama yang valid</b> (harus mulai dengan http:// atau https://):`);
      return true;
    }
    state.oldUrl = text;
    state.step = "waiting_new_url";
    modStates.set(userId, state);
    await sendHtml(chatId,
      `✅ URL lama: <code>${text}</code>\n\nSekarang kirim <b>URL server baru</b>:`,
      [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]]
    );
    return true;
  }

  // STEP 2: waiting_new_url
  if (state.step === "waiting_new_url") {
    if (!text || !text.startsWith("http")) {
      await sendHtml(chatId, `⚠️ <b>Kirim URL baru yang valid</b> (harus mulai dengan http:// atau https://):`);
      return true;
    }
    await processDomainChange(chatId, userId, state, text);
    return true;
  }

  // STEP: waiting_zip_renameall
  if (state.step === "waiting_zip_renameall") {
    const media = msg.media;
    if (!media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
      return true;
    }
    const doc = media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.endsWith(".zip")) {
      await sendHtml(chatId, `❌ <b>Harus file <code>.zip</code>!</b>`);
      return true;
    }
    if (doc.size > 500 * 1024 * 1024) {
      await sendHtml(chatId, `❌ <b>Maks ukuran ZIP: 500 MB.</b>`);
      return true;
    }
    const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh ZIP...</b>`);
    try {
      if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
      const localZip = tmpPath(`mod_renameall_${userId}_${Date.now()}.zip`);
      await client.downloadMedia(msg, { outputFile: localZip });
      if (!fs.existsSync(localZip)) throw new Error("Gagal download ZIP");

      state.step = "waiting_old_text";
      state.localZip = localZip;
      modStates.set(userId, state);
      await editHtml(chatId, statusMsg.id, `✅ ZIP diterima.\n\nKetik <b>teks lama</b> yang mau diganti (persis sama, case-sensitive):`);
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal proses ZIP!</b>\n\n<blockquote>${err.message}</blockquote>`);
      modStates.delete(userId);
    }
    return true;
  }

  // STEP: waiting_old_text
  if (state.step === "waiting_old_text") {
    if (!text || !text.trim()) {
      await sendHtml(chatId, `⚠️ <b>Ketik teks lama yang valid:</b>`);
      return true;
    }
    state.oldUrl = text.trim(); // reuse field oldUrl krn fungsi replace sama
    state.step = "waiting_new_text";
    modStates.set(userId, state);
    await sendHtml(chatId, `✅ Teks lama: <code>${text.trim()}</code>\n\nSekarang ketik <b>teks baru</b>:`,
      [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]]);
    return true;
  }

  // STEP: waiting_new_text
  if (state.step === "waiting_new_text") {
    if (!text || !text.trim()) {
      await sendHtml(chatId, `⚠️ <b>Ketik teks baru yang valid:</b>`);
      return true;
    }
    await processDomainChange(chatId, userId, state, text.trim()); // pakai proses yang sama
    return true;
  }

  // STEP: waiting_zip_color
  if (state.step === "waiting_zip_color") {
    const media = msg.media;
    if (!media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
      return true;
    }
    const doc      = media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.endsWith(".zip")) {
      await sendHtml(chatId, `❌ <b>Harus file <code>.zip</code>!</b>`);
      return true;
    }
    if (doc.size > 500 * 1024 * 1024) {
      await sendHtml(chatId, `❌ <b>Maks ukuran ZIP untuk fitur ini: 500 MB.</b>`);
      return true;
    }

    const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh & memindai warna...</b>`);
    try {
      if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
      const localZip = tmpPath(`mod_color_${userId}_${Date.now()}.zip`);
      await client.downloadMedia(msg, { outputFile: localZip });
      if (!fs.existsSync(localZip)) throw new Error("Gagal download ZIP");

      const colors = fluttermod.scanDominantColors(localZip);
      state.localZip = localZip;
      state.step = "waiting_pick_color";

      if (colors.length === 0) {
        state.oldHex = null;
      } else {
        state.oldHex = colors[0][0];
      }
      modStates.set(userId, state);

      const detectedText = state.oldHex
        ? `Warna dominan terdeteksi: <code>#${state.oldHex}</code>`
        : `Tidak ada warna hex terdeteksi otomatis — kamu tetap bisa lanjut, tapi kemungkinan tidak ada yang diganti.`;

      await editHtml(chatId, statusMsg.id,
        `🎨 <b>Ganti Warna APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>${detectedText}</blockquote>\n\n` +
        `Pilih warna pengganti:`,
        keyboardColorPresets()
      );
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses ZIP!</b>\n\n<blockquote>${err.message}</blockquote>`);
      modStates.delete(userId);
    }
    return true;
  }

  // STEP: waiting_custom_hex
  if (state.step === "waiting_custom_hex") {
    const hex = (text || "").replace("#", "").trim();
    if (!fluttermod.isValidHex(hex)) {
      await sendHtml(chatId, `⚠️ <b>Format hex tidak valid.</b>\n\n<blockquote>Kirim 6 digit hex, contoh: <code>FF5733</code></blockquote>`);
      return true;
    }
    await processColorChange(chatId, userId, state, hex.toUpperCase());
    return true;
  }

  // STEP: waiting_zip_icon
  if (state.step === "waiting_zip_icon") {
    const media = msg.media;
    if (!media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
      return true;
    }
    const doc      = media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.endsWith(".zip")) {
      await sendHtml(chatId, `❌ <b>Harus file <code>.zip</code>!</b>`);
      return true;
    }
    if (doc.size > 500 * 1024 * 1024) {
      await sendHtml(chatId, `❌ <b>Maks ukuran ZIP untuk fitur ini: 500 MB.</b>`);
      return true;
    }

    const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh & memindai icon...</b>`);
    try {
      if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
      const localZip = tmpPath(`mod_icon_${userId}_${Date.now()}.zip`);
      await client.downloadMedia(msg, { outputFile: localZip });
      if (!fs.existsSync(localZip)) throw new Error("Gagal download ZIP");

      const targets = fluttermod.scanIconTargets(localZip);
      if (targets.length === 0) {
        await editHtml(chatId, statusMsg.id, `⚠️ <b>Tidak ditemukan slot icon Android/iOS di project ini.</b>`);
        safeCleanupModState(userId, state);
        return true;
      }

      state.localZip = localZip;
      state.step = "waiting_icon_image";
      state.iconTargetsCount = targets.length;
      modStates.set(userId, state);

      await editHtml(chatId, statusMsg.id,
        `🖼️ <b>Ganti Icon APK</b>\n${DIV_HTML}\n\n` +
        `<blockquote>✅ Ditemukan ${targets.length} slot icon (Android + iOS).</blockquote>\n\n` +
        `📤 Sekarang kirim gambar icon baru (PNG/JPG, disarankan persegi 1:1):`
      );
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses ZIP!</b>\n\n<blockquote>${err.message}</blockquote>`);
      modStates.delete(userId);
    }
    return true;
  }

  if (state.step === "waiting_icon_image") {
    const media = msg.media;
    if (!media?.photo && !media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim gambar (foto atau file PNG/JPG)!</b>`);
      return true;
    }
    if (!(await requireAndSpendCredit(chatId, userId))) { safeCleanupModState(userId, state); return true; }
    const statusMsg = await sendHtml(chatId, `⚙️ <b>Mengganti icon...</b>`);
    try {
      const iconPath = tmpPath(`icon_src_${userId}_${Date.now()}.png`);
      await client.downloadMedia(msg, { outputFile: iconPath });
      const iconBuffer = await fs.promises.readFile(iconPath);
      fs.unlink(iconPath, () => {});

      const outZip = tmpPath(`mod_icon_out_${userId}_${Date.now()}.zip`);
      const result = await fluttermod.replaceIconInZip(state.localZip, outZip, iconBuffer);

      if (result.changedCount === 0) {
        await editHtml(chatId, statusMsg.id, `⚠️ <b>Tidak ada icon yang berhasil diganti.</b>`);
        credits.addCredits(userId, CREDIT_COST); // refund
        safeCleanupModState(userId, state);
        return true;
      }

      const resizeNote = result.resized
        ? "✅ Icon otomatis di-resize sesuai ukuran tiap slot."
        : "⚠️ Modul resize (sharp) tidak tersedia di server — icon dipasang tanpa resize otomatis.";

      await editHtml(chatId, statusMsg.id,
        `✅ <b>Icon Berhasil Diganti!</b>\n${DIV_HTML}\n\n` +
        `<blockquote>📝 ${result.changedCount} file icon diganti.\n${resizeNote}</blockquote>\n\n` +
        `📦 Mengirim ZIP hasil...`
      );

      await notifyChannelAction(chatId, userId, "mod_icon", "Ganti Icon APK", { jumlah: `${result.changedCount} file` });

      await client.sendFile(chatId, {
        file: outZip,
        caption: `📦 <b>ZIP Hasil Ganti Icon</b>\n${DIV_HTML}\n\n<blockquote>Siap dibuild.</blockquote>`,
        parseMode: "html",
        forceDocument: true,
      });
      await fs.promises.unlink(outZip).catch(() => {});
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal mengganti icon!</b>\n\n<blockquote>${err.message}</blockquote>`);
      credits.addCredits(userId, CREDIT_COST); // refund
    } finally {
      safeCleanupModState(userId, state);
    }
    return true;
  }

  // STEP: waiting_zip_name
  if (state.step === "waiting_zip_name") {
    const media = msg.media;
    if (!media?.document) {
      await sendHtml(chatId, `⚠️ <b>Kirim file ZIP-nya ya, bukan teks!</b>`);
      return true;
    }
    const doc      = media.document;
    const fileName = doc.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.endsWith(".zip")) {
      await sendHtml(chatId, `❌ <b>Harus file <code>.zip</code>!</b>`);
      return true;
    }
    if (doc.size > 500 * 1024 * 1024) {
      await sendHtml(chatId, `❌ <b>Maks ukuran ZIP untuk fitur ini: 500 MB.</b>`);
      return true;
    }

    const statusMsg = await sendHtml(chatId, `🔄 <b>Mengunduh ZIP...</b>`);
    try {
      if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
      const localZip = tmpPath(`mod_name_${userId}_${Date.now()}.zip`);
      await client.downloadMedia(msg, { outputFile: localZip });
      if (!fs.existsSync(localZip)) throw new Error("Gagal download ZIP");

      state.localZip = localZip;
      state.step = "waiting_new_name";
      modStates.set(userId, state);

      await editHtml(chatId, statusMsg.id,
        `✏️ <b>Ganti Nama APK</b>\n${DIV_HTML}\n\n📝 Kirim nama aplikasi baru:`
      );
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal memproses ZIP!</b>\n\n<blockquote>${err.message}</blockquote>`);
      modStates.delete(userId);
    }
    return true;
  }

  if (state.step === "waiting_new_name") {
    if (!text || text.length < 1 || text.length > 50) {
      await sendHtml(chatId, `⚠️ <b>Nama harus 1-50 karakter.</b> Kirim ulang:`);
      return true;
    }
    if (!(await requireAndSpendCredit(chatId, userId))) { safeCleanupModState(userId, state); return true; }
    const statusMsg = await sendHtml(chatId, `⚙️ <b>Mengganti nama app...</b>`);
    try {
      const outZip = tmpPath(`mod_name_out_${userId}_${Date.now()}.zip`);
      const result = fluttermod.replaceAppNameInZip(state.localZip, outZip, text);

      if (result.totalOccurrences === 0) {
        await editHtml(chatId, statusMsg.id, `⚠️ <b>Tidak ditemukan tempat untuk mengganti nama app.</b>`);
        credits.addCredits(userId, CREDIT_COST); // refund
        safeCleanupModState(userId, state);
        return true;
      }

      const fileList = result.changedFiles.map(f => `• <code>${f.file}</code> (${f.count}x)`).join("\n");

      await editHtml(chatId, statusMsg.id,
        `✅ <b>Nama App Berhasil Diganti!</b>\n${DIV_HTML}\n\n` +
        `<blockquote>✏️ Nama baru: <b>${text}</b>\n📝 Total: ${result.totalOccurrences}x di ${result.changedFiles.length} file\n\n${fileList}</blockquote>\n\n` +
        `📦 Mengirim ZIP hasil...`
      );

      await notifyChannelAction(chatId, userId, "mod_name", "Ganti Nama APK", { nama: text });

      await client.sendFile(chatId, {
        file: outZip,
        caption: `📦 <b>ZIP Hasil Ganti Nama</b>\n${DIV_HTML}\n\n<blockquote>Nama app: <b>${text}</b></blockquote>`,
        parseMode: "html",
        forceDocument: true,
      });
      await fs.promises.unlink(outZip).catch(() => {});
    } catch (err) {
      await editHtml(chatId, statusMsg.id, `❌ <b>Gagal mengganti nama!</b>\n\n<blockquote>${err.message}</blockquote>`);
      credits.addCredits(userId, CREDIT_COST); // refund
    } finally {
      safeCleanupModState(userId, state);
    }
    return true;
  }

  // DEPLOY WEB: waiting_name
  if (state.step === "deployweb_waiting_name") {
    if (!text) {
      await sendHtml(chatId, `⚠️ <b>Ketik nama subdomain kamu:</b>`);
      return true;
    }
    const clean = cleanAlphaNum(text.trim());
    if (clean.length < 3) {
      await sendHtml(chatId,
        `⚠️ <b>Nama minimal 3 karakter, huruf kecil & angka saja.</b>\n\nKetik ulang:`
      );
      return true;
    }
    state.projectName = clean;
    state.step = "deployweb_waiting_html";
    modStates.set(userId, state);
    await sendHtml(chatId,
      `✅ <b>Nama Tersimpan!</b>\n\n` +
      `<blockquote>🌍 Subdomain: <code>https://${clean}.vercel.app</code></blockquote>\n\n` +
      `📤 Sekarang kirim:\n` +
      `• File <code>.html</code> tunggal, <b>atau</b>\n` +
      `• File <code>.zip</code> project web (html+css+js+gambar)`,
      [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]]
    );
    return true;
  }

  // DEPLOY WEB: waiting_html
  if (state.step === "deployweb_waiting_html") {
    const projectName = state.projectName;

    const doc = msg.media?.document;
    const fileName = doc?.attributes?.find(a => a.fileName)?.fileName || "";
    if (doc && fileName.toLowerCase().endsWith(".zip")) {
      if (doc.size > 50 * 1024 * 1024) {
        await sendHtml(chatId, `⚠️ <b>Maks ukuran ZIP untuk deploy web: 50 MB.</b>`);
        return true;
      }
      modStates.delete(userId);
      await runDeployWebZipFlow(chatId, userId, msg, projectName);
      return true;
    }

    const html = await extractHTMLGeneric(msg, chatId);
    if (!html) return true;
    modStates.delete(userId);
    await runDeployWebFlow(chatId, userId, html, projectName);
    return true;
  }

  // ENC HTML
  if (state.step === "enc_html_b64" || state.step === "enc_html_obf" || state.step === "dec_html_b64") {
    const html = await extractHTMLGeneric(msg, chatId);
    if (!html) return true;
    modStates.delete(userId);
    await runEncHTMLFlow(chatId, userId, html, state.step);
    return true;
  }

  // ENC JS
  if (state.step === "enc_js_wait") {
    const js = await extractJSGeneric(msg, chatId);
    if (!js) return true;
    const mode = state.jsMode;
    modStates.delete(userId);
    await runEncJSFlow(chatId, userId, js, mode, msg.document?.file_name || msg.media?.document?.attributes?.find(a => a.fileName)?.fileName);
    return true;
  }

  if (state.step === "dec_js_b64") {
    const js = await extractJSGeneric(msg, chatId);
    if (!js) return true;
    modStates.delete(userId);
    await runDecJSFlow(chatId, userId, js);
    return true;
  }

  return false;
}

// ─── PROCESS DOMAIN CHANGE ─────────────────────────────────────────────────
async function processDomainChange(chatId, userId, state, newUrl, msgId = null) {
  if (!(await requireAndSpendCredit(chatId, userId, msgId))) { safeCleanupModState(userId, state); return; }

  const statusMsg = msgId
    ? { id: msgId }
    : await sendHtml(chatId, `⚙️ <b>Mengganti domain...</b>`);

  try {
    const outZip = tmpPath(`mod_domain_out_${userId}_${Date.now()}.zip`);
    const result = fluttermod.replaceDomainInZip(state.localZip, outZip, state.oldUrl, newUrl);

    if (result.totalOccurrences === 0) {
      await editHtml(chatId, statusMsg.id,
        `⚠️ <b>URL lama tidak ditemukan di file manapun.</b>\n\n<blockquote>Pastikan URL yang kamu ketik sama persis dengan yang ada di kode.</blockquote>`
      );
      credits.addCredits(userId, CREDIT_COST); // refund
      safeCleanupModState(userId, state);
      return;
    }

    const fileList = result.changedFiles.map(f => `• <code>${f.file}</code> (${f.count}x)`).join("\n");

    await editHtml(chatId, statusMsg.id,
      `✅ <b>Domain Berhasil Diganti!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `<blockquote>` +
      `🔻 Lama: <code>${state.oldUrl}</code>\n` +
      `🔺 Baru: <code>${newUrl}</code>\n` +
      `📝 Total: ${result.totalOccurrences}x di ${result.changedFiles.length} file\n\n` +
      `${fileList}` +
      `</blockquote>\n\n` +
      `📦 Mengirim file ZIP hasil...`
    );

    const buffer = await fs.promises.readFile(outZip);
    credits.logDeploy({ userId, type: "mod_domain", domain: newUrl, oldDomain: state.oldUrl });
    await notifyChannelAction(chatId, userId, "mod_domain", "Ganti Domain APK", {});
    await client.sendFile(chatId, {
      file: outZip,
      caption:
        `📦 <b>ZIP Hasil Ganti Domain</b>\n${DIV_HTML}\n\n` +
        `<blockquote>Siap dibuild atau langsung dipakai.</blockquote>`,
      parseMode: "html",
      forceDocument: true,
    });

    await fs.promises.unlink(outZip).catch(() => {});
  } catch (err) {
    await editHtml(chatId, statusMsg.id, `❌ <b>Gagal mengganti domain!</b>\n\n<blockquote>${err.message}</blockquote>`);
    credits.addCredits(userId, CREDIT_COST); // refund
  } finally {
    safeCleanupModState(userId, state);
  }
}

// ─── PROCESS COLOR CHANGE ──────────────────────────────────────────────────
async function processColorChange(chatId, userId, state, newHex, msgId = null) {
  if (!(await requireAndSpendCredit(chatId, userId, msgId))) { safeCleanupModState(userId, state); return; }

  const statusMsg = msgId
    ? { id: msgId }
    : await sendHtml(chatId, `⚙️ <b>Mengganti warna...</b>`);

  try {
    if (!state.oldHex) {
      await editHtml(chatId, statusMsg.id,
        `⚠️ <b>Tidak ada warna lama yang terdeteksi untuk diganti.</b>\n\n<blockquote>Project ini mungkin tidak punya warna hex hardcoded di kode.</blockquote>`
      );
      credits.addCredits(userId, CREDIT_COST); // refund
      safeCleanupModState(userId, state);
      return;
    }

    const outZip = tmpPath(`mod_color_out_${userId}_${Date.now()}.zip`);
    const result = fluttermod.replaceColorInZip(state.localZip, outZip, state.oldHex, newHex);

    if (result.totalOccurrences === 0) {
      await editHtml(chatId, statusMsg.id,
        `⚠️ <b>Tidak ada file yang berhasil diganti.</b>`
      );
      credits.addCredits(userId, CREDIT_COST); // refund
      safeCleanupModState(userId, state);
      return;
    }

    const fileList = result.changedFiles.map(f => `• <code>${f.file}</code> (${f.count}x)`).join("\n");

    await editHtml(chatId, statusMsg.id,
      `✅ <b>Warna Berhasil Diganti!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n\n` +
      `<blockquote>` +
      `🔻 Lama: <code>#${state.oldHex}</code>\n` +
      `🔺 Baru: <code>#${newHex}</code>\n` +
      `📝 Total: ${result.totalOccurrences}x di ${result.changedFiles.length} file\n\n` +
      `${fileList}` +
      `</blockquote>\n\n` +
      `📦 Mengirim file ZIP hasil...`
    );

    await notifyChannelAction(chatId, userId, "mod_color", "Ganti Warna APK", {
      lama: `#${state.oldHex}`, baru: `#${newHex}`,
    });
    await client.sendFile(chatId, {
      file: outZip,
      caption:
        `📦 <b>ZIP Hasil Ganti Warna</b>\n${DIV_HTML}\n\n` +
        `<blockquote>Warna theme + splash sudah diperbarui.</blockquote>`,
      parseMode: "html",
      forceDocument: true,
    });

    await fs.promises.unlink(outZip).catch(() => {});
  } catch (err) {
    await editHtml(chatId, statusMsg.id, `❌ <b>Gagal mengganti warna!</b>\n\n<blockquote>${err.message}</blockquote>`);
    credits.addCredits(userId, CREDIT_COST); // refund
  } finally {
    safeCleanupModState(userId, state);
  }
}

function safeCleanupModState(userId, state) {
  if (state?.localZip && fs.existsSync(state.localZip)) {
    fs.unlink(state.localZip, () => {});
  }
  modStates.delete(userId);
}

// ─── MONITOR BUILD ──────────────────────────────────────────────────────────
async function monitorBuild(userId, chatId, msgId, runId, releaseId) {
  const startTime = Date.now();
  let lastStatus  = "";
  let chanMsgId   = null;

  const job         = getUserJob(userId) || {};
  const displayMode = job.buildType === "debug" ? "🐞 Debug Build" : job.type === "web2apk" ? "🌐 Web to APK" : "🚀 Release Build";
  const userDisplay = job.fullName && job.fullName !== "Unknown User" ? job.fullName : (job.username ? `@${job.username}` : `User_${userId}`);
  const projDisplay = job.type === "web2apk" ? (job.appName || "Web App") : (job.fileName || "Flutter Project");
  const prioText    = priorityTag(userId);
  const notifPhoto  = job.type === "web2apk" ? NOTIF_PHOTOS.web2apk : NOTIF_PHOTOS.build_apk;

  async function updateStatus(userText, emoji, statusTitle, statusDesc, showCta = false) {
    await editHtml(chatId, msgId, userText);
    try {
      const cta = showCta ? [[{ text: "🚀 Mau Build Juga? Gas!", url: `https://t.me/${(await client.getMe()).username}?start` }]] : null;
      const chanText =
        `${emoji} <b>LIVE BUILD MONITOR</b> ${emoji}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<blockquote>` +
        `👤 Developer : ${userDisplay}\n` +
        `🆔 User ID   : <code>${userId}</code>\n` +
        `🎯 Priority  : ${prioText}\n` +
        `📦 Project   : <code>${projDisplay}</code>\n` +
        `🔧 Mode      : <code>${displayMode}</code>` +
        `</blockquote>\n\n` +
        `<blockquote>` +
        `📊 STATUS : <b>${statusTitle}</b>\n` +
        `💬 DETAIL : ${statusDesc}\n` +
        `⏱ WAKTU  : <code>${formatDuration(Math.floor((Date.now() - startTime) / 1000))}</code>` +
        `</blockquote>`;
      if (!chanMsgId) {
        // PAKAI SENDPHOTOSAFE
        const m = await sendPhotoSafe(client, CONFIG.CHANNEL_USERNAME, notifPhoto, {
          caption: chanText, parseMode: "html",
          buttons: cta ? buildButtons(cta) : undefined,
          tmpDir: CONFIG.TMP_DIR,
        });
        chanMsgId = m.id;
      } else {
        await client.editMessage(CONFIG.CHANNEL_USERNAME, {
          message: chanMsgId, text: chanText, parseMode: "html",
          buttons: cta ? buildButtons(cta) : undefined,
        });
      }
    } catch (e) { console.error("Channel update error:", e.message); }
  }

  while (true) {
    if (Date.now() - startTime > CONFIG.BUILD_TIMEOUT_MS) {
      if (releaseId) await deleteRelease(releaseId).catch(() => {});
      const j = getUserJob(userId);
      if (j?.iconReleaseId) await deleteRelease(j.iconReleaseId).catch(() => {});
      removeUserJob(userId);
      hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "timeout", duration: Math.floor((Date.now() - startTime) / 1000), at: new Date().toISOString() });
      await updateStatus(
        `🛑 <b>[ BUILD TIMEOUT ]</b>\n\n` +
        `<blockquote>` +
        `📡 Server  : <code>🔴 TIMEOUT</code>\n` +
        `🔧 Mode    : <code>${displayMode}</code>\n` +
        `📦 Project : <code>${projDisplay}</code>\n` +
        `⏱ Limit   : <code>${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} Menit</code>\n\n` +
        `⚠️ Waktu habis! Cek dependensi kodenya dan coba lagi.` +
        `</blockquote>`,
        "🛑", "TIMEOUT", "Build melampaui batas waktu.", false
      );
      return;
    }

    const run     = await getRunStatus(runId);
    const elapsed = Math.floor((Date.now() - startTime) / 1000);

    if (run.status === "queued" && lastStatus !== "queued") {
      lastStatus = "queued";
      await updateStatus(
        `⏳ <b>[ MENUNGGU SERVER ]</b>\n\n` +
        `<blockquote>` +
        `📡 Server   : <code>🟢 ONLINE</code>\n` +
        `🎯 Priority : ${prioText}\n` +
        `🔧 Mode     : <code>${displayMode}</code>\n` +
        `📦 Project  : <code>${projDisplay}</code>\n` +
        `⏱ Waktu    : <code>${formatDuration(elapsed)}</code>\n\n` +
        `☕ VM sedang disiapkan. Jangan batalkan!` +
        `</blockquote>`,
        "⏳", "MENUNGGU RUNNER", "VM sedang dipersiapkan.", true
      );

    } else if (run.status === "in_progress") {
      lastStatus = "in_progress";
      const pct = Math.min(Math.round((elapsed / 300) * 100), 95);
      await updateStatus(
        `⚡ <b>[ SEDANG KOMPILASI ]</b>\n\n` +
        `<blockquote>` +
        `📡 Server   : <code>🟡 PROCESSING</code>\n` +
        `🎯 Priority : ${prioText}\n` +
        `🔧 Mode     : <code>${displayMode}</code>\n` +
        `📦 Project  : <code>${projDisplay}</code>\n` +
        `📊 Progress : <code>${progressBar(pct)}</code> <b>${pct}%</b>\n` +
        `⏱ Waktu    : <code>${formatDuration(elapsed)}</code>\n\n` +
        `🚀 Flutter SDK sedang kompilasi. Stay tune!` +
        `</blockquote>`,
        "⚡", `COMPILING (${pct}%)`, "Flutter SDK mengompilasi source code ke APK.", true
      );

    } else if (run.status === "completed") {
      if (run.conclusion === "success") {
        db.incrementStat("success");
        await updateStatus(
          `📦 <b>[ MENGAMBIL APK ]</b>\n\n` +
          `<blockquote>` +
          `📡 Server  : <code>🟢 SUCCESS</code>\n` +
          `⏱ Durasi  : <code>${formatDuration(run.durationSec)}</code>\n` +
          `📦 Project : <code>${projDisplay}</code>\n\n` +
          `🎉 Kompilasi sukses! Mengambil APK dari cloud...` +
          `</blockquote>`,
          "📦", "UPLOADING ARTIFACT", "Memindahkan APK ke Telegram."
        );

        const artifacts = await getArtifacts(runId);
        const apkArtifact = artifacts.find(a => a.name.toLowerCase().includes("apk") || a.name.toLowerCase().includes("build")) || artifacts[0];

        if (!apkArtifact) {
          removeUserJob(userId);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          await updateStatus(`⚠️ <b>File APK Tidak Ditemukan!</b>\n\n<blockquote>Kompilasi sukses tapi output APK tidak terdeteksi. Hubungi admin.</blockquote>`, "⚠️", "MISSING ARTIFACT", "Output APK tidak ditemukan.");
          return;
        }

        const zipDest = tmpPath(`flutter_${Date.now()}.zip`);
        await downloadArtifactZip(apkArtifact.id, zipDest);
        const zip      = new AdmZip(zipDest);
        const apkEntry = zip.getEntries().find(e => e.entryName.endsWith(".apk"));

        if (!apkEntry) {
          removeUserJob(userId);
          fs.unlinkSync(zipDest);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          await updateStatus(`⚠️ <b>APK Tidak Ada di Arsip!</b>\n\n<blockquote>Isi ZIP output kosong atau korup. Hubungi admin.</blockquote>`, "⚠️", "BAD ZIP", "File APK tidak ditemukan dalam arsip.");
          return;
        }

        const apkDest  = tmpPath(`flutter_${Date.now()}.apk`);
        fs.writeFileSync(apkDest, apkEntry.getData());
        fs.unlinkSync(zipDest);
        const apkSize  = (fs.statSync(apkDest).size / 1024 / 1024).toFixed(2);

        await editHtml(chatId, msgId,
          `🚀 <b>Mengupload APK...</b>\n\n` +
          `<blockquote>Kompilasi sukses! APK <code>${apkSize} MB</code> sedang dikirim ke chat kamu...</blockquote>`
        );

        await client.sendFile(chatId, {
          file: apkDest,
          caption:
            `🎉 <b>APK SIAP DIGUNAKAN!</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<blockquote>` +
            `⏱ Durasi   : <b>${formatDuration(run.durationSec)}</b>\n` +
            `💾 Ukuran   : <b>${apkSize} MB</b>\n` +
            `🔧 Mode     : <b>${displayMode}</b>\n` +
            `🎯 Priority : ${prioText}` +
            `</blockquote>\n\n` +
            `<i>Terima kasih sudah menggunakan ${CONFIG.BOT_NAME}! 🚀</i>`,
          parseMode: "html",
        });

        hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "success", apkSize, duration: run.durationSec, at: new Date().toISOString() });

        try {
          await client.editMessage(CONFIG.CHANNEL_USERNAME, {
            message: chanMsgId,
            text:
              `🎉 <b>BUILD SUCCESS!</b>\n` +
              `━━━━━━━━━━━━━━━━━━━━\n` +
              `<blockquote>` +
              `👤 Developer : ${userDisplay}\n` +
              `📦 Project   : <code>${projDisplay}</code>\n` +
              `🔧 Mode      : <code>${displayMode}</code>\n` +
              `⏱ Durasi    : <code>${formatDuration(run.durationSec)}</code>\n` +
              `💾 Ukuran    : <code>${apkSize} MB</code>\n` +
              `🟢 Status    : <b>SUKSES TERKIRIM</b>` +
              `</blockquote>`,
            parseMode: "html",
          });
        } catch (_) {}

        fs.unlinkSync(apkDest);
        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        const curJob = getUserJob(userId);
        if (curJob?.iconReleaseId) await deleteRelease(curJob.iconReleaseId).catch(() => {});
        removeUserJob(userId);
        return;

      } else {
        db.incrementStat("failed");
        await updateStatus(
          `❌ <b>[ BUILD GAGAL ]</b>\n\n` +
          `<blockquote>` +
          `📡 Server  : <code>🔴 FAILED</code>\n` +
          `🔧 Mode    : <code>${displayMode}</code>\n` +
          `📦 Project : <code>${projDisplay}</code>\n\n` +
          `🔍 Mengambil log error dari server...` +
          `</blockquote>`,
          "❌", "BUILD FAILED", "Error pada source code."
        );

        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        await sleep(3000);

        const errDetail = await Promise.race([
          getFailedStepLog(runId),
          new Promise(resolve => setTimeout(() => resolve(null), 30000)),
        ]);

        hdb.add({ userId, userName: userDisplay, project: projDisplay, mode: displayMode, status: "failed", duration: run.durationSec, at: new Date().toISOString() });

        let errText =
          `❌ <b>BUILD FAILED</b>\n\n` +
          `<blockquote>` +
          `🔴 Step gagal : <code>${errDetail?.stepName || "Kompilasi Utama"}</code>\n` +
          `⏱ Durasi     : <code>${formatDuration(run.durationSec)}</code>` +
          `</blockquote>`;

        if (errDetail?.errorLines?.length) {
          errText += `\n\n<pre>${errDetail.errorLines.join("\n").slice(0, 1500)}</pre>`;
          await editHtml(chatId, msgId, errText);

          const logFile = tmpPath(`build_error_${userId}_${Date.now()}.txt`);
          fs.writeFileSync(logFile, `BUILD FAILED\nStep: ${errDetail.stepName}\n=====\n${errDetail.errorLines.join("\n")}`);
          await client.sendFile(chatId, {
            file: logFile,
            caption: `📄 <b>Full Build Error Log</b>\n\n<i>Gunakan file ini untuk menemukan baris kode yang error secara detail.</i>`,
            parseMode: "html",
          });
          if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
        } else {
          errText += `\n\n<blockquote>Gagal mengambil log error otomatis dari server.</blockquote>`;
          await editHtml(chatId, msgId, errText);
        }

        const curJob = getUserJob(userId);
        if (curJob?.iconReleaseId) await deleteRelease(curJob.iconReleaseId).catch(() => {});
        removeUserJob(userId);
        return;
      }
    }
    await sleep(CONFIG.POLL_INTERVAL_MS);
  }
}

// ─── QUEUE ──────────────────────────────────────────────────────────────────
const queueMessages = new Map();

async function handleQueue(chatId, delId = null) {
  try {
    const qs   = getQueueStats();
    const cs   = db.getStats();
    const jobs = getSortedActiveJobs();

    let text =
      `<b>📊 STATUS BUILD QUEUE</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `<blockquote>` +
      `⏳ Menunggu  : <b>${qs.waiting}</b>\n` +
      `☁️ Uploading : <b>${qs.uploading}</b>\n` +
      `⚙️ Building  : <b>${qs.building}</b>` +
      `</blockquote>\n\n`;

    if (jobs.length === 0) {
      text += `<i>🚫 Tidak ada build aktif saat ini.</i>\n\n`;
    } else {
      text += `🔥 <b>Build Aktif (${jobs.length})</b>\n\n`;
      jobs.forEach((j, i) => {
        const icon = j.status === "building" ? "⚙️" : j.status === "uploading" ? "☁️" : "⏳";
        const prioIcon = getUserPriority(j.userId) === 1 ? "👑" : getUserPriority(j.userId) === 2 ? "🤝" : "👤";
        const elapsed  = formatDuration(elapsedSec(j.updatedAt));
        const usr      = j.fullName && j.fullName !== "Unknown User" ? j.fullName : (j.username ? `@${j.username}` : `User_${j.userId}`);
        text +=
          `${i + 1}. ${prioIcon} ${icon} <b>${usr}</b>\n` +
          `<blockquote>` +
          `Status : ${statusLabel(j.status)}\n` +
          `Mode   : ${j.buildType === "debug" ? "🐞 Debug" : j.type === "web2apk" ? "🌐 Web2APK" : "🚀 Release"}\n` +
          `Aktif  : ${elapsed}` +
          `</blockquote>\n`;
      });
    }

    text +=
      `\n<blockquote>` +
      `🟢 Sukses: <b>${cs.success}</b>  |  🔴 Gagal: <b>${cs.failed}</b>\n` +
      `🕒 ${nowTimeWib()} WIB` +
      `</blockquote>`;

    const btns = [[{ text: "🔄 Refresh", data: "queue" }, { text: "🏠 Menu Utama", data: "start" }]];

    if (delId) { try { await client.deleteMessages(chatId, [delId], { revoke: true }); } catch (_) {} }
    else {
      const old = queueMessages.get(chatId);
      if (old) { try { await client.deleteMessages(chatId, [old]); } catch (_) {} }
    }

    const m = await client.sendMessage(chatId, { message: text, buttons: buildButtons(btns), parseMode: "html" });
    queueMessages.set(chatId, m.id);
  } catch (err) {
    console.error("handleQueue error:", err);
  }
}

// ─── STATUS BOT ──────────────────────────────────────────────────────────────
async function handleStatus(chatId, userId, delId = null) {
  const qs      = getQueueStats();
  const uptime  = formatDuration(Math.floor(process.uptime()));
  const cs      = db.getStats();
  const total   = cs.success + cs.failed;
  const rate    = total > 0 ? ((cs.success / total) * 100).toFixed(1) : "0.0";

  const totalRam = (os.totalmem() / 1073741824).toFixed(2);
  const freeRam  = (os.freemem()  / 1073741824).toFixed(2);
  const usedRam  = (totalRam - freeRam).toFixed(2);
  const ramPct   = ((usedRam / totalRam) * 100).toFixed(1);
  const cpus     = os.cpus();
  const cpuModel = cpus[0]?.model?.trim() || "Unknown";
  const cpuLoad  = (os.loadavg()[0] * 100 / cpus.length).toFixed(1);

  let disk = { total: "N/A", used: "N/A", free: "N/A", pct: "N/A" };
  try {
    const df = execSync("df -h / | tail -1").toString().trim().split(/\s+/);
    if (df.length >= 5) disk = { total: df[1], used: df[2], free: df[3], pct: df[4] };
  } catch (_) {}

  let cloud = "Generic KVM";
  try {
    const v = execSync("cat /sys/class/dmi/id/sys_vendor 2>/dev/null").toString().trim().toLowerCase();
    const p = execSync("cat /sys/class/dmi/id/product_name 2>/dev/null").toString().trim().toLowerCase();
    if (v.includes("digitalocean")) cloud = "DigitalOcean Droplet";
    else if (v.includes("amazon")) cloud = "AWS EC2";
    else if (v.includes("google")) cloud = "Google Cloud (GCP)";
    else if (v.includes("linode")) cloud = "Linode VPS";
    else if (v.includes("vultr"))  cloud = "Vultr VPS";
    else if (v.includes("qemu") || p.includes("kvm")) cloud = "KVM Virtual Server";
    else if (v.length > 0) cloud = `${v.toUpperCase()}`;
  } catch (_) {}

  const ping = await new Promise(resolve => {
    const start = Date.now();
    const s = new net.Socket();
    s.setTimeout(2000);
    s.connect(443, "api.github.com", () => {
      const ms = Date.now() - start;
      s.destroy();
      resolve(`${ms}ms — ${ms > 350 ? "🔴 Lambat" : ms > 150 ? "🟡 Sedang" : "🟢 Bagus"}`);
    });
    s.on("error",   () => { s.destroy(); resolve("❌ Gagal"); });
    s.on("timeout", () => { s.destroy(); resolve("❌ Timeout"); });
  });

  await sendHtml(chatId,
    `⚙️ <b>INFRASTRUKTUR BOT</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<b>🤖 Bot Info</b>\n` +
    `<blockquote>` +
    `📦 Nama    : ${CONFIG.BOT_NAME} <code>v${CONFIG.BOT_VERSION}</code>\n` +
    `🟢 Status  : Online / Active\n` +
    `⏱ Uptime  : ${uptime}\n` +
    `👥 User DB : ${db.getAllUsers().length} pengguna\n` +
    `✅ Sukses  : ${cs.success} build\n` +
    `❌ Gagal   : ${cs.failed} build\n` +
    `📈 Rate    : <b>${rate}%</b>` +
    `</blockquote>\n\n` +
    `<b>📊 Queue Engine</b>\n` +
    `<blockquote>` +
    `⏳ Menunggu  : ${qs.waiting}\n` +
    `☁️ Uploading : ${qs.uploading}\n` +
    `⚙️ Building  : ${qs.building}` +
    `</blockquote>\n\n` +
    `<b>☁️ Cloud Server</b>\n` +
    `<blockquote>` +
    `🌐 Provider : <code>${cloud}</code>\n` +
    `⚡ Ping     : <code>${ping}</code>\n` +
    `🐧 OS       : ${os.type()} ${os.release()} (${os.arch()})` +
    `</blockquote>\n\n` +
    `<b>💾 Hardware</b>\n` +
    `<blockquote>` +
    `🧠 CPU  : ${cpuModel} (${cpus.length} Core)\n` +
    `⚡ Load : <code>${cpuLoad}%</code>\n` +
    `🗄️ RAM  : <code>${usedRam}/${totalRam} GB (${ramPct}%)</code>\n` +
    `💽 SSD  : <code>${disk.used}/${disk.total} (${disk.pct})</code>` +
    `</blockquote>\n\n` +
    `<i>🕒 ${nowWib()} WIB</i>`,
    [[{ text: "🔄 Refresh", data: "status" }, { text: "🏠 Menu Utama", data: "start" }]],
    delId
  );
}

// ─── HELP ────────────────────────────────────────────────────────────────────
async function handleHelp(chatId, delId = null) {
  await sendHtml(chatId,
    `📖 <b>PANDUAN ${CONFIG.BOT_NAME.toUpperCase()}</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `<b>🚀 Build APK Flutter</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🚀 Mulai Build APK</b>\n` +
    `2️⃣ Pilih mode Debug / Release\n` +
    `3️⃣ Kirim file ZIP project Flutter\n` +
    `4️⃣ Bot build di cloud &amp; kirim APK otomatis` +
    `</blockquote>\n\n` +
    `<b>🌐 Web to APK</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🌐 Web to APK</b>\n` +
    `2️⃣ Kirim URL website\n` +
    `3️⃣ Kirim nama aplikasi\n` +
    `4️⃣ Kirim logo/icon (PNG/JPG)\n` +
    `5️⃣ APK dikirim otomatis` +
    `</blockquote>\n\n` +
    `<b>🔧 Ganti Domain APK</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🔧 Ganti Domain APK</b>\n` +
    `2️⃣ Kirim ZIP project Flutter\n` +
    `3️⃣ Pilih URL lama yang terdeteksi (atau ketik manual)\n` +
    `4️⃣ Kirim URL server baru\n` +
    `5️⃣ Bot kirim balik ZIP hasil ganti domain` +
    `</blockquote>\n\n` +
    `<b>🎨 Ganti Warna APK</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🎨 Ganti Warna APK</b>\n` +
    `2️⃣ Kirim ZIP project Flutter\n` +
    `3️⃣ Pilih warna preset atau custom hex\n` +
    `4️⃣ Bot kirim balik ZIP dengan theme + splash sudah diganti` +
    `</blockquote>\n\n` +
    `<b>🖼️ Ganti Icon APK</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🖼️ Ganti Icon</b>\n` +
    `2️⃣ Kirim ZIP project Flutter\n` +
    `3️⃣ Kirim gambar icon baru (PNG/JPG)\n` +
    `4️⃣ Bot kirim balik ZIP dengan icon Android+iOS sudah diganti` +
    `</blockquote>\n\n` +
    `<b>✏️ Ganti Nama APK</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>✏️ Ganti Nama</b>\n` +
    `2️⃣ Kirim ZIP project Flutter\n` +
    `3️⃣ Kirim nama aplikasi baru\n` +
    `4️⃣ Bot kirim balik ZIP dengan nama sudah diganti` +
    `</blockquote>\n\n` +
    `<b>🚀 Deploy Web ke Vercel</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🚀 Deploy Web</b>\n` +
    `2️⃣ Ketik nama subdomain (jadi nama.vercel.app)\n` +
    `3️⃣ Kirim file <code>.html</code> tunggal atau <code>.zip</code> project web\n` +
    `4️⃣ Bot otomatis push GitHub &amp; deploy Vercel\n` +
    `5️⃣ Dapat link production siap pakai` +
    `</blockquote>\n\n` +
    `<b>🔐 Enkripsi HTML/JS</b>\n` +
    `<blockquote>` +
    `1️⃣ Klik <b>🔐 Enkripsi</b>\n` +
    `2️⃣ Pilih HTML (Base64/Obfuscate/Dekripsi) atau JS (15+ mode)\n` +
    `3️⃣ Kirim file, hasil dikirim otomatis` +
    `</blockquote>\n\n` +
    `<b>📋 Ketentuan</b>\n` +
    `<blockquote>` +
    `• Maks <b>1 build aktif</b> per user\n` +
    `• Maks ukuran ZIP: <b>2 GB</b>\n` +
    `• Timeout build: <b>${Math.round(CONFIG.BUILD_TIMEOUT_MS / 60000)} menit</b>` +
    `</blockquote>\n\n` +
    `<b>🔑 Perintah Admin</b>\n` +
    `<blockquote>` +
    `/broadcast — Kirim pesan ke semua user\n` +
    `/addreseller &lt;id&gt; — Tambah reseller\n` +
    `/removereseller &lt;id&gt; — Hapus reseller\n` +
    `/searchuser &lt;query&gt; — Cari user\n` +
    `/userinfo &lt;id&gt; — Info detail user\n` +
    `/deleteuser &lt;id&gt; — Hapus user dari DB\n` +
    `/banuser &lt;id&gt; [alasan] — Ban user\n` +
    `/unbanuser &lt;id&gt; — Unban user\n` +
    `/dmuser &lt;id&gt; &lt;pesan&gt; — Kirim DM ke user\n` +
    `/exportusers — Export CSV semua user\n` +
    `/buildhistory — Riwayat build\n` +
    `/killbuild &lt;id&gt; — Force kill build user` +
    `</blockquote>`,
    [
      [{ text: "🚀 Mulai Build APK", data: "build", style: "Success" }, { text: "🌐 Web to APK", data: "web2apk", style: "Success" }],
      [{ text: "🏠 Menu Utama", data: "start", style: "Danger" }],
    ],
    delId
  );
}

// ─── WEB2APK ────────────────────────────────────────────────────────────────
async function handleWeb2Apk(chatId, userId, delId = null) {
  if (CONFIG.WEB2APK_MAINTENANCE) {
    await sendHtml(chatId,
      `🛠️ <b>Fitur Dalam Maintenance</b>\n\n` +
      `<blockquote>Fitur Web to APK sementara ditutup untuk peningkatan sistem.\n\nGunakan Build APK biasa untuk sementara.</blockquote>`,
      [[{ text: "🏠 Menu Utama", data: "start", style: "Danger" }]], delId
    );
    return;
  }
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await sendHtml(chatId,
      `⚠️ <b>Build Aktif!</b>\n\n<blockquote>Status: ${statusLabel(job.status)}\n\nTunggu selesai atau batalkan dulu.</blockquote>`,
      [[{ text: "❌ Batalkan Build", data: "cancel" }]], delId
    );
    return;
  }

  let username = null, fullName = "Unknown User";
  try {
    const e = await client.getEntity(userId);
    username = e?.username || null;
    fullName = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown User";
  } catch (_) {}

  const priority = getUserPriority(userId);
  setUserJob(userId, { status: "waiting_url", chatId, userId, username, fullName, type: "web2apk", updatedAt: Date.now(), priority });

  const prioMsg = priority === 1 ? `\n\n<blockquote>👑 <b>OWNER PRIORITY (Level 1)</b></blockquote>`
    : priority === 2           ? `\n\n<blockquote>🤝 <b>RESELLER PRIORITY (Level 2)</b></blockquote>`
    : "";

  await sendHtml(chatId,
    `🌐 <b>Web to APK — Langkah 1/3</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>URL website</b> yang ingin dijadikan APK.${prioMsg}\n\n` +
    `<blockquote>📌 Contoh: <code>https://example.com</code></blockquote>`,
    [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], delId
  );
}

async function handleWeb2ApkUrl(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text   = event.message.text?.trim();
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_url" || job.type !== "web2apk") return;
  try { new URL(text); } catch {
    await sendHtml(chatId, `❌ <b>URL tidak valid!</b>\n\n<blockquote>Contoh: <code>https://example.com</code></blockquote>`);
    return;
  }
  setUserJob(userId, { ...job, status: "waiting_appname", webUrl: text, updatedAt: Date.now() });
  await sendHtml(chatId,
    `✅ <b>URL Tersimpan!</b>\n\n` +
    `🌐 <b>Web to APK — Langkah 2/3</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>nama aplikasi</b> yang diinginkan.\n\n` +
    `<blockquote>📌 Contoh: <code>Toko Online Saya</code></blockquote>`,
    [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]]
  );
}

async function handleWeb2ApkName(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text   = event.message.text?.trim();
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_appname" || job.type !== "web2apk") return;
  setUserJob(userId, { ...job, status: "waiting_icon", appName: text, updatedAt: Date.now() });
  await sendHtml(chatId,
    `✅ <b>Nama App Tersimpan!</b>\n\n` +
    `🌐 <b>Web to APK — Langkah 3/3</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Kirim <b>foto/logo</b> untuk icon APK.\n\n` +
    `<blockquote>📌 Tips:\n• Kirim sebagai foto atau file gambar\n• Disarankan ukuran 1:1 (persegi)\n• Format: PNG, JPG</blockquote>`,
    [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]]
  );
}

async function handleWeb2ApkIcon(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const job    = getUserJob(userId);
  if (!job || job.status !== "waiting_icon" || job.type !== "web2apk") return false;
  const media = event.message.media;
  if (!media) return false;
  if (!media.photo && !media.document) {
    await sendHtml(chatId, `⚠️ <b>Kirim ikon dalam bentuk Foto atau File Gambar!</b>`);
    return true;
  }

  if (!(await requireAndSpendCredit(chatId, userId))) { removeUserJob(userId); return true; }

  const statusMsg = await sendHtml(chatId,
    `⚙️ <b>Memproses Web to APK...</b>\n\n` +
    `<blockquote>🌐 URL  : <code>${job.webUrl}</code>\n📱 Nama : <code>${job.appName}</code>\n\n🔥 Memproses icon...</blockquote>`
  );
  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });
    const iconPath = tmpPath(`icon_${userId}_${Date.now()}.png`);
    await client.downloadMedia(event.message, { outputFile: iconPath });
    await editHtml(chatId, msgId,
      `⚙️ <b>Memproses Web to APK...</b>\n\n` +
      `<blockquote>🌐 URL  : <code>${job.webUrl}</code>\n📱 Nama : <code>${job.appName}</code>\n\n☁️ Menyiapkan aset di GitHub Release...</blockquote>`
    );
    const tag = genTag(userId);
    const { releaseId: iconReleaseId, uploadUrl } = await createReleaseOnly(tag);
    await uploadAssetFile(uploadUrl, iconPath, "icon.png", "image/png");
    if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath);
    const iconUrl = await publishRelease(iconReleaseId);
    if (!iconUrl) throw new Error("URL icon gagal diambil!");
    const runId = await triggerWeb2ApkWorkflow(job.webUrl, job.appName, iconUrl);
    setUserJob(userId, { ...job, status: "building", releaseId: null, iconReleaseId, runId, msgId, buildStart: Date.now(), updatedAt: Date.now() });
    await editHtml(chatId, msgId,
      `⚙️ <b>Build Web to APK Dimulai!</b>\n\n` +
      `<blockquote>🌐 URL  : <code>${job.webUrl}</code>\n📱 Nama : <code>${job.appName}</code>\n🆔 Run  : <code>${runId}</code>\n\n🔍 Memantau progress...</blockquote>`
    );
    monitorBuild(userId, chatId, msgId, runId, null).catch(async err => {
      removeUserJob(userId);
      credits.addCredits(userId, CREDIT_COST); // refund
      await editHtml(chatId, msgId, `❌ <b>Error Build Server!</b>\n\n<blockquote>${err.message}</blockquote>`);
    });
  } catch (err) {
    removeUserJob(userId);
    credits.addCredits(userId, CREDIT_COST); // refund
    await editHtml(chatId, msgId, `❌ <b>Gagal Memproses Asset!</b>\n\n<blockquote>${err.message}</blockquote>`);
  }
  return true;
}

// ─── REPORT ──────────────────────────────────────────────────────────────────
async function handleUserReportMessages(event) {
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const chatId = event.chatId;
  const state  = userStates.get(userId);
  if (!state) return false;

  if (state.step === "WAITING_FOR_REASON") {
    if (!event.message.text || event.message.text.length < 10) {
      await client.sendMessage(chatId, {
        message: "⚠️ **Mohon berikan alasan yang lebih detail (minimal 10 karakter).**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "user_cancel_lapor" }]]),
        parseMode: "md"
      });
      return true;
    }
    userStates.set(userId, { step: "WAITING_FOR_SCREENSHOT", reason: event.message.text });
    await client.sendMessage(chatId, {
      message: "📸 **BUKTI SCREENSHOT**\n\nKirimkan **1 Foto/Screenshot** bukti pendukung.",
      parseMode: "md",
      buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "user_cancel_lapor" }]])
    });
    return true;
  }

  if (state.step === "WAITING_FOR_SCREENSHOT") {
    if (!event.message.media || !(event.message.media instanceof Api.MessageMediaPhoto)) {
      await client.sendMessage(chatId, {
        message: "⚠️ **Format salah! Kirimkan bukti berupa Foto/Gambar.**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "user_cancel_lapor" }]]),
        parseMode: "md"
      });
      return true;
    }
    const username = sender?.username ? `@${sender.username}` : "—";
    const name     = sender?.firstName || "User";
    try {
      const reportPath = tmpPath(`report_${userId}_${Date.now()}.jpg`);
      await client.downloadMedia(event.message, { outputFile: reportPath });
      await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
        message:
          `🚨 <b>LAPORAN MASUK</b>\n\n` +
          `<blockquote>` +
          `👤 Nama    : ${name}\n` +
          `🆔 ID      : <code>${userId}</code>\n` +
          `🌐 Username: ${username}\n\n` +
          `📝 Alasan:\n${state.reason}` +
          `</blockquote>`,
        file: reportPath,
        parseMode: "html",
        buttons: buildButtons([
          [{ text: "✅ Selesai", data: `adm_fix_${userId}` }],
          [{ text: "🔒 Blokir", data: `adm_blk_${userId}` }, { text: "🔓 Unblokir", data: `adm_unblk_${userId}` }]
        ])
      });
      if (fs.existsSync(reportPath)) fs.unlinkSync(reportPath);
      await client.sendMessage(chatId, {
        message: `✅ **Laporan Terkirim!**\n\nTerima kasih, laporan kamu sudah masuk ke sistem admin.`,
        parseMode: "md"
      });
    } catch (e) {
      await client.sendMessage(chatId, { message: "❌ Gagal mengirim laporan." });
    }
    userStates.delete(userId);
    return true;
  }
  return false;
}

// ─── ADMIN COMMANDS ──────────────────────────────────────────────────────────
async function handleAddReseller(chatId, userId, targetId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, `❌ <b>Akses ditolak!</b>`); return; }
  if (!targetId) { await sendHtml(chatId, `➕ <b>Tambah Reseller</b>\n\n<blockquote>Gunakan: <code>/addreseller 123456789</code></blockquote>`); return; }
  const num = Number(targetId);
  if (isNaN(num)) { await sendHtml(chatId, `❌ <b>ID tidak valid!</b>`); return; }
  const info = db.getUserById(num);
  if (rdb.add(num, info?.username, userId)) {
    await sendHtml(chatId, `✅ <b>Reseller ditambahkan!</b>\n\n<blockquote>🆔 ID: <code>${num}</code>\n👤 Username: ${info?.username || "—"}\n🎯 Priority Level 2</blockquote>`);
    try { await client.sendMessage(num, { message: `🎉 **SELAMAT!**\n\nKamu sekarang menjadi **RESELLER** dari ${CONFIG.BOT_NAME}!\n\n✨ Priority Level 2 - Build diprioritaskan!`, parseMode: "md" }); } catch (_) {}
  } else {
    await sendHtml(chatId, `❌ <b>User ID <code>${num}</code> sudah menjadi reseller.</b>`);
  }
}

async function handleRemoveReseller(chatId, userId, targetId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, `❌ <b>Akses ditolak!</b>`); return; }
  if (!targetId) { await sendHtml(chatId, `➖ <b>Hapus Reseller</b>\n\n<blockquote>Gunakan: <code>/removereseller 123456789</code></blockquote>`); return; }
  const num = Number(targetId);
  if (rdb.remove(num)) {
    await sendHtml(chatId, `✅ <b>Reseller dihapus!</b>\n\n<blockquote>🆔 ID: <code>${num}</code></blockquote>`);
    try { await client.sendMessage(num, { message: `⚠️ **PEMBERITAHUAN**\n\nStatus reseller kamu telah dicabut.`, parseMode: "md" }); } catch (_) {}
  } else {
    await sendHtml(chatId, `❌ <b>ID <code>${num}</code> bukan reseller.</b>`);
  }
}

// ─── LIST USERS ──────────────────────────────────────────────────────────────
async function handleListUsers(chatId, userId, page = 1, editId = null) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }

  const all      = db.getAllUsers();
  const perPage  = 8;
  const total    = Math.max(1, Math.ceil(all.length / perPage));
  page           = Math.min(Math.max(1, page), total);
  const slice    = all.slice((page - 1) * perPage, page * perPage);

  let text =
    `<b>👥 DAFTAR USER (${all.length})</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  slice.forEach((u, i) => {
    const role    = roleTag(u.userId);
    const isRes   = rdb.isReseller(u.userId);
    const isBan   = bdb.isBanned(u.userId);
    const joinStr = fmtDate(u.joinedAt);
    text +=
      `<b>${(page - 1) * perPage + i + 1}. ${role}${isBan ? " 🚫" : ""}</b>\n` +
      `<blockquote>` +
      `🆔 ID       : <code>${u.userId}</code>\n` +
      `👤 Nama     : ${u.name || "Unknown"}\n` +
      `🌐 Username : ${u.username || "—"}\n` +
      `📅 Join     : ${joinStr}` +
      `</blockquote>\n`;
  });

  const nav = [];
  if (page > 1)    nav.push({ text: "◀️ Prev", data: `listusers_page_${page - 1}` });
  nav.push({ text: `📄 ${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "Next ▶️", data: `listusers_page_${page + 1}` });

  const btns = [
    nav,
    [{ text: "🔍 Cari User", data: "admin_search_user" }, { text: "📤 Export", data: "admin_export_users" }],
    [{ text: "◀ Admin Panel", data: "admin_panel" }],
  ];

  editId
    ? await client.editMessage(chatId, { message: editId, text, buttons: buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── LIST RESELLERS ──────────────────────────────────────────────────────────
async function handleListResellers(chatId, userId, page = 1, editId = null) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }

  const all     = rdb.all();
  const perPage = 8;
  const total   = Math.max(1, Math.ceil(all.length / perPage));
  page          = Math.min(Math.max(1, page), total);
  const slice   = all.slice((page - 1) * perPage, page * perPage);

  let text =
    `<b>🤝 DAFTAR RESELLER (${all.length})</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  if (all.length === 0) {
    text += `<i>Belum ada reseller yang terdaftar.</i>`;
  } else {
    slice.forEach((r, i) => {
      text +=
        `<b>${(page - 1) * perPage + i + 1}. 🤝 RESELLER</b>\n` +
        `<blockquote>` +
        `🆔 ID          : <code>${r.userId}</code>\n` +
        `🌐 Username    : ${r.username || "—"}\n` +
        `📅 Ditambahkan : ${fmtDate(r.addedAt)}\n` +
        `🎯 Priority    : Level 2` +
        `</blockquote>\n`;
    });
  }

  const nav = [];
  if (page > 1)    nav.push({ text: "◀️ Prev", data: `listresellers_page_${page - 1}` });
  nav.push({ text: `📄 ${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "Next ▶️", data: `listresellers_page_${page + 1}` });

  const btns = [nav, [{ text: "◀ Admin Panel", data: "admin_panel" }]];

  editId
    ? await client.editMessage(chatId, { message: editId, text, buttons: buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── BUILD HISTORY ───────────────────────────────────────────────────────────
async function handleBuildHistory(chatId, userId, page = 1, editId = null) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }

  const all     = hdb.all();
  const perPage = 6;
  const total   = Math.max(1, Math.ceil(all.length / perPage));
  page          = Math.min(Math.max(1, page), total);
  const slice   = all.slice((page - 1) * perPage, page * perPage);

  let text =
    `<b>📋 RIWAYAT BUILD (${all.length})</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Halaman ${page}/${total}</i>\n\n`;

  if (all.length === 0) {
    text += `<i>Belum ada riwayat build.</i>`;
  } else {
    slice.forEach((h, i) => {
      const statusIcon = h.status === "success" ? "✅" : h.status === "timeout" ? "⏱️" : "❌";
      text +=
        `<b>${(page - 1) * perPage + i + 1}. ${statusIcon} ${h.status.toUpperCase()}</b>\n` +
        `<blockquote>` +
        `👤 User    : ${h.userName || `ID:${h.userId}`}\n` +
        `📦 Project : <code>${h.project || "—"}</code>\n` +
        `🔧 Mode    : ${h.mode || "—"}\n` +
        (h.apkSize  ? `💾 APK     : <code>${h.apkSize} MB</code>\n` : "") +
        (h.duration ? `⏱ Durasi  : <code>${formatDuration(h.duration)}</code>\n` : "") +
        `📅 Waktu   : ${fmtDateTime(h.at)}` +
        `</blockquote>\n`;
    });
  }

  const cs   = db.getStats();
  const tot  = cs.success + cs.failed;
  const rate = tot > 0 ? ((cs.success / tot) * 100).toFixed(1) : "0.0";
  text +=
    `\n<blockquote>` +
    `✅ Total Sukses : <b>${cs.success}</b>\n` +
    `❌ Total Gagal  : <b>${cs.failed}</b>\n` +
    `📈 Success Rate : <b>${rate}%</b>` +
    `</blockquote>`;

  const nav = [];
  if (page > 1)    nav.push({ text: "◀️ Prev", data: `buildhistory_page_${page - 1}` });
  nav.push({ text: `📄 ${page}/${total}`, data: "noop" });
  if (page < total) nav.push({ text: "Next ▶️", data: `buildhistory_page_${page + 1}` });

  const btns = [nav, [{ text: "◀ Admin Panel", data: "admin_panel" }]];

  editId
    ? await client.editMessage(chatId, { message: editId, text, buttons: buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── SEARCH USER ─────────────────────────────────────────────────────────────
async function handleSearchUser(chatId, userId, query) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!query) {
    await sendHtml(chatId,
      `🔍 <b>Cari User</b>\n\n` +
      `<blockquote>Gunakan:\n<code>/searchuser 123456789</code>\n<code>/searchuser @username</code>\n<code>/searchuser nama</code></blockquote>`
    );
    return;
  }
  const results = db.searchUsers(query);
  if (results.length === 0) {
    await sendHtml(chatId,
      `🔍 <b>Hasil Pencarian</b>\n\n<blockquote>Tidak ada user cocok dengan: <code>${query}</code></blockquote>`,
      [[{ text: "◀ Admin Panel", data: "admin_panel" }]]
    );
    return;
  }
  let text = `🔍 <b>Hasil Pencarian "${query}" (${results.length})</b>\n━━━━━━━━━━━━━━━━━━━━\n\n`;
  results.slice(0, 10).forEach(u => {
    text +=
      `<b>${roleTag(u.userId)}${bdb.isBanned(u.userId) ? " 🚫" : ""}</b>\n` +
      `<blockquote>` +
      `🆔 ID       : <code>${u.userId}</code>\n` +
      `👤 Nama     : ${u.name || "Unknown"}\n` +
      `🌐 Username : ${u.username || "—"}\n` +
      `📅 Join     : ${fmtDate(u.joinedAt)}` +
      `</blockquote>\n`;
  });
  if (results.length > 10) text += `\n<i>+${results.length - 10} hasil lainnya</i>`;
  await sendHtml(chatId, text, [[{ text: "◀ Admin Panel", data: "admin_panel" }]]);
}

// ─── USER INFO ──────────────────────────────────────────────────────────────
async function handleUserInfo(chatId, userId, targetId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!targetId) {
    await sendHtml(chatId,
      `ℹ️ <b>Info User</b>\n\n<blockquote>Gunakan: <code>/userinfo 123456789</code></blockquote>`
    );
    return;
  }
  const num  = Number(targetId);
  const u    = db.getUserById(num);
  if (!u) { await sendHtml(chatId, `❌ <b>User ID <code>${num}</code> tidak ditemukan!</b>`); return; }

  const isRes = rdb.isReseller(num);
  const isBan = bdb.isBanned(num);
  const ban   = isBan ? bdb.getInfo(num) : null;
  const job   = getUserJob(num);

  let tgInfo = "—";
  try {
    const e = await client.getEntity(num);
    tgInfo  = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "—";
  } catch (_) {}

  const text =
    `ℹ️ <b>INFO USER</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `<blockquote>` +
    `🆔 ID           : <code>${num}</code>\n` +
    `👤 Nama (DB)    : ${u.name || "Unknown"}\n` +
    `👤 Nama (TG)    : ${tgInfo}\n` +
    `🌐 Username     : ${u.username || "—"}\n` +
    `🏅 Role         : ${roleTag(num)}\n` +
    `📅 Join         : ${fmtDateTime(u.joinedAt)}\n` +
    `⏰ Last Active  : ${fmtDateTime(u.lastActive)}\n` +
    `🤝 Reseller     : ${isRes ? "✅ Ya" : "❌ Tidak"}\n` +
    `🚫 Status Ban   : ${isBan ? `🔴 Dibanned\n📋 Alasan: ${ban?.reason || "—"}\n📅 Dibanned: ${fmtDate(ban?.bannedAt)}` : "🟢 Normal"}\n` +
    `⚙️ Build Aktif  : ${job ? `✅ ${statusLabel(job.status)}` : "❌ Tidak ada"}` +
    `</blockquote>`;

  const btns = [
    isRes
      ? [{ text: "➖ Remove Reseller", data: `adm_rm_reseller_${num}` }]
      : [{ text: "➕ Add Reseller", data: `adm_add_reseller_${num}` }],
    isBan
      ? [{ text: "✅ Unban User", data: `adm_unban_${num}` }]
      : [{ text: "🚫 Ban User", data: `adm_ban_${num}` }],
    [{ text: "◀ Admin Panel", data: "admin_panel" }],
  ];

  await sendHtml(chatId, text, btns);
}

// ─── BAN / UNBAN ─────────────────────────────────────────────────────────────
async function handleBanUser(chatId, userId, args) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!args) {
    await sendHtml(chatId, `🚫 <b>Ban User</b>\n\n<blockquote>Gunakan: <code>/banuser 123456789 alasan ban</code></blockquote>`);
    return;
  }
  const parts  = args.trim().split(/\s+/);
  const num    = Number(parts[0]);
  const reason = parts.slice(1).join(" ") || "Melanggar ketentuan";
  if (isNaN(num))     { await sendHtml(chatId, "❌ ID tidak valid!"); return; }
  if (isOwner(num))   { await sendHtml(chatId, "❌ Tidak bisa ban Owner!"); return; }
  if (bdb.ban(num, reason, userId)) {
    await sendHtml(chatId,
      `🚫 <b>User Dibanned!</b>\n\n` +
      `<blockquote>🆔 ID     : <code>${num}</code>\n📋 Alasan : ${reason}</blockquote>`,
      [[{ text: "◀ Admin Panel", data: "admin_panel" }]]
    );
    try {
      await client.sendMessage(num, {
        message: `🚫 **AKUN ANDA DIBANNED**\n\nKamu tidak bisa menggunakan bot ini.\n\n📋 Alasan: ${reason}\n\nHubungi admin jika ini kesalahan.`,
        parseMode: "md"
      });
    } catch (_) {}
  } else {
    await sendHtml(chatId, `❌ User ID <code>${num}</code> sudah dalam status ban.`);
  }
}

async function handleUnbanUser(chatId, userId, targetId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!targetId) {
    await sendHtml(chatId, `✅ <b>Unban User</b>\n\n<blockquote>Gunakan: <code>/unbanuser 123456789</code></blockquote>`);
    return;
  }
  const num = Number(targetId);
  if (bdb.unban(num)) {
    await sendHtml(chatId,
      `✅ <b>User Diunban!</b>\n\n<blockquote>🆔 ID: <code>${num}</code></blockquote>`,
      [[{ text: "◀ Admin Panel", data: "admin_panel" }]]
    );
    try {
      await client.sendMessage(num, {
        message: `✅ **AKSES DIKEMBALIKAN**\n\nAkun kamu telah diunban. Kamu bisa menggunakan bot ini kembali.`,
        parseMode: "md"
      });
    } catch (_) {}
  } else {
    await sendHtml(chatId, `❌ User ID <code>${num}</code> tidak sedang dalam status ban.`);
  }
}

// ─── KILL BUILD ──────────────────────────────────────────────────────────────
async function handleListBuildsForKill(chatId, userId, editId = null) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  const jobs = getSortedActiveJobs();

  let text =
    `💀 <b>FORCE KILL BUILD</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n`;

  if (jobs.length === 0) {
    text += `<i>Tidak ada build aktif saat ini.</i>`;
    const btns = [[{ text: "◀ Admin Panel", data: "admin_panel" }]];
    editId
      ? await client.editMessage(chatId, { message: editId, text, buttons: buildButtons(btns), parseMode: "html" })
      : await sendHtml(chatId, text, btns);
    return;
  }

  text += `<i>Pilih build yang ingin dihentikan paksa:</i>\n\n`;
  jobs.forEach((j, i) => {
    const usr = j.fullName && j.fullName !== "Unknown User" ? j.fullName : (j.username ? `@${j.username}` : `User_${j.userId}`);
    text +=
      `${i + 1}. <b>${roleTag(j.userId)}</b> — ${usr}\n` +
      `<blockquote>Status: ${statusLabel(j.status)}  |  ${formatDuration(elapsedSec(j.updatedAt))}</blockquote>\n`;
  });

  const btns = [
    ...jobs.map(j => {
      const usr = j.fullName && j.fullName !== "Unknown User" ? j.fullName.split(" ")[0] : (j.username || `U${j.userId}`);
      return [{ text: `💀 Kill: ${usr}`, data: `kill_build_${j.userId}` }];
    }),
    [{ text: "◀ Admin Panel", data: "admin_panel" }],
  ];

  editId
    ? await client.editMessage(chatId, { message: editId, text, buttons: buildButtons(btns), parseMode: "html" })
    : await sendHtml(chatId, text, btns);
}

// ─── DELETE USER / EXPORT / DM ──────────────────────────────────────────────
async function handleDeleteUser(chatId, userId, targetId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!targetId) { await sendHtml(chatId, `🗑️ <b>Hapus User</b>\n\n<blockquote>Gunakan: <code>/deleteuser 123456789</code></blockquote>`); return; }
  const num = Number(targetId);
  if (isNaN(num))   { await sendHtml(chatId, "❌ ID tidak valid!"); return; }
  if (isOwner(num)) { await sendHtml(chatId, "❌ Tidak bisa menghapus Owner!"); return; }
  const u = db.getUserById(num);
  if (!u) { await sendHtml(chatId, `❌ User ID <code>${num}</code> tidak ditemukan.`); return; }
  db.deleteUser(num);
  rdb.remove(num);
  await sendHtml(chatId,
    `✅ <b>User Dihapus!</b>\n\n<blockquote>🆔 ID: <code>${num}</code>\n👤 Nama: ${u.name || "Unknown"}</blockquote>`,
    [[{ text: "◀ Admin Panel", data: "admin_panel" }]]
  );
}

async function handleExportUsers(chatId, userId) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  const all  = db.getAllUsers();
  const res  = rdb.all();
  const ban  = bdb.all();
  const hdrs = ["No","User ID","Nama","Username","Role","Reseller","Banned","Join Date","Last Active"];
  const rows = all.map((u, i) => {
    const isRes = res.some(r => r.userId === u.userId);
    const isBan = ban.some(b => b.userId === u.userId);
    const role  = isOwner(u.userId) ? "OWNER" : isRes ? "RESELLER" : isAdmin(u.userId) ? "ADMIN" : "USER";
    return [i + 1, u.userId, u.name || "Unknown", u.username || "-", role, isRes ? "Ya" : "Tidak", isBan ? "Ya" : "Tidak", fmtDate(u.joinedAt), fmtDate(u.lastActive)];
  });
  const csv     = [hdrs, ...rows].map(r => r.join(",")).join("\n");
  const csvPath = tmpPath(`users_export_${Date.now()}.csv`);
  fs.writeFileSync(csvPath, csv, "utf-8");
  try {
    await client.sendFile(chatId, {
      file: csvPath,
      caption:
        `📤 <b>Export Database User</b>\n\n` +
        `<blockquote>📊 Total User    : ${all.length}\n🤝 Total Reseller: ${res.length}\n🚫 Total Banned  : ${ban.length}\n📅 Diekspor      : ${nowWib()}</blockquote>`,
      parseMode: "html",
      forceDocument: true,
    });
    if (fs.existsSync(csvPath)) fs.unlinkSync(csvPath);
  } catch (e) {
    if (fs.existsSync(csvPath)) fs.unlinkSync(csvPath);
    await sendHtml(chatId, `❌ Gagal export: <code>${e.message}</code>`);
  }
}

async function handleDmUser(chatId, userId, args) {
  if (!isPrivileged(userId)) { await sendHtml(chatId, "❌ Akses ditolak!"); return; }
  if (!args) { await sendHtml(chatId, `📣 <b>Kirim DM ke User</b>\n\n<blockquote>Gunakan: <code>/dmuser 123456789 pesan kamu</code></blockquote>`); return; }
  const parts = args.trim().split(/\s+/);
  const num   = Number(parts[0]);
  const msg   = parts.slice(1).join(" ");
  if (isNaN(num) || !msg) { await sendHtml(chatId, `❌ Format salah!\n\n<blockquote>Gunakan: <code>/dmuser 123456789 pesan</code></blockquote>`); return; }
  try {
    await client.sendMessage(num, { message: msg, parseMode: "md" });
    await sendHtml(chatId,
      `✅ <b>Pesan Terkirim!</b>\n\n<blockquote>🆔 Ke: <code>${num}</code>\n💬 Pesan: ${msg}</blockquote>`,
      [[{ text: "◀ Admin Panel", data: "admin_panel" }]]
    );
  } catch (e) {
    await sendHtml(chatId, `❌ Gagal kirim: <code>${e.message}</code>`);
  }
}

// ─── CALLBACK ────────────────────────────────────────────────────────────────
async function handleCallback(event) {
  try {
    const data   = event.data.toString();
    const chatId = event.chatId;
    const userId = Number(event.senderId);
    const msgId  = event.messageId;

    // Broadcast
    if (data.startsWith("broadcast_approve_")) {
      if (!isOwner(userId)) return await event.answer({ message: "❌ Hanya Owner!", alert: true });
      try { await client.sendMessage(parseInt(data.split("_")[2]), { message: `✅ **Broadcast disetujui Owner!**`, parseMode: "md" }); } catch (_) {}
      return await event.answer({ message: "✅ Disetujui!" });
    }
    if (data.startsWith("broadcast_reject_")) {
      if (!isOwner(userId)) return await event.answer({ message: "❌ Hanya Owner!", alert: true });
      try { await client.sendMessage(parseInt(data.replace("broadcast_reject_", "")), { message: `❌ **Broadcast ditolak Owner!**`, parseMode: "md" }); } catch (_) {}
      return await event.answer({ message: "❌ Ditolak!" });
    }

    // Noop
    if (data === "noop") return await event.answer();

    // ─── CREDIT: Saldo saya + link referral ───────────────────────────────
    if (data === "credit_me") {
      await event.answer();
      const stats = credits.getReferralStats(userId);
      const { link } = await getReferralLink();
      const saldo = isPrivileged(userId) ? "♾️ Unlimited (Owner/Admin)" : `${stats.credits} Credit`;
      return await sendHtml(chatId,
        `💰 <b>Credit Saya</b>\n${DIV_HTML}\n\n` +
        `<blockquote>` +
        `💳 Saldo         : <b>${saldo}</b>\n` +
        `🎁 Teman Join    : <b>${stats.confirmedReferrals}</b> orang\n` +
        `⏳ Menunggu Join : <b>${stats.pendingReferrals}</b> orang\n\n` +
        `🔗 Link Undangan Kamu:\n<code>${link(userId)}</code>\n\n` +
        `Setiap 1 orang join lewat link kamu dan bergabung ke channel, kamu dapat <b>+${credits.REFERRAL_BONUS} credit</b> gratis!` +
        `</blockquote>`,
        [
          [{ text: "🛒 Beli / Redeem Credit", data: "credit_buy" }],
          [{ text: "🏠 Menu Utama", data: "start" }],
        ], msgId
      );
    }

    // ─── CREDIT: Menu beli / redeem ────────────────────────────────────────
    if (data === "credit_buy") {
      await event.answer();
      return await sendHtml(chatId,
        `🛒 <b>Beli / Redeem Credit</b>\n${DIV_HTML}\n\n` +
        `<blockquote>` +
        `Pilih paket di bawah untuk order manual ke admin, atau tukar kode redeem kalau kamu punya.\n\n` +
        `💡 Gratis: share link undangan kamu di menu <b>Credit Saya</b>!` +
        `</blockquote>`,
        buyCreditKeyboard(), msgId
      );
    }

    // Step 1: user pencet paket -> tampilkan konfirmasi pembelian
    if (data.startsWith("buy_") && CREDIT_PACKAGES[data.replace("buy_", "")]) {
      const pkgKey = data.replace("buy_", "");
      const pkg = CREDIT_PACKAGES[pkgKey];
      await event.answer();
      return await sendHtml(chatId,
        `🛒 <b>Konfirmasi Pembelian</b>\n${DIV_HTML}\n\n` +
        `<blockquote>📦 Paket : <b>${pkg.label}</b>\n💵 Harga : <b>${formatIDR(pkg.priceIDR)}</b></blockquote>\n\n` +
        `Lanjutkan pembelian?`,
        [
          [{ text: "✅ Konfirmasi", data: `buyconfirm_${pkgKey}` }],
          [{ text: "❌ Batal", data: "credit_buy", style: "Danger" }],
        ], msgId
      );
    }

    // Step 2: user konfirmasi -> pilih metode pembayaran
    if (data.startsWith("buyconfirm_")) {
      const pkgKey = data.replace("buyconfirm_", "");
      const pkg = CREDIT_PACKAGES[pkgKey];
      if (!pkg) return await event.answer({ message: "❌ Paket tidak valid.", alert: true });
      await event.answer();
      return await sendHtml(chatId,
        `💳 <b>Pilih Metode Pembayaran</b>\n${DIV_HTML}\n\n` +
        `<blockquote>📦 Paket : <b>${pkg.label}</b>\n💵 Harga : <b>${formatIDR(pkg.priceIDR)}</b></blockquote>`,
        [
          [{ text: "🇶 QRIS", data: `paymethod_${pkgKey}_qris` }, { text: "💗 DANA", data: `paymethod_${pkgKey}_dana` }],
          [{ text: "❌ Batal", data: "credit_buy", style: "Danger" }],
        ], msgId
      );
    }

    // Step 3: user pilih metode -> kirim notif ke admin utk ACC & minta admin siapkan pembayaran
    if (data.startsWith("paymethod_")) {
      const [, pkgKey, method] = data.match(/^paymethod_(.+)_(qris|dana)$/) || [];
      const pkg = pkgKey && CREDIT_PACKAGES[pkgKey];
      if (!pkg) return await event.answer({ message: "❌ Paket tidak valid.", alert: true });
      await event.answer();

      const orderId = `${userId}_${Date.now()}`;
      let name = "Unknown", buyerUname = "—";
      try {
        const e = await client.getEntity(userId);
        name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
        buyerUname = e?.username ? `@${e.username}` : "—";
      } catch (_) {}

      pendingOrders.set(orderId, {
        userId, chatId, pkgKey, method, name, buyerUname,
        status: "waiting_admin_method_ack", createdAt: Date.now(),
      });

      try {
        await client.sendMessage(CONFIG.OWNER_ID, {
          message:
            `🛒 <b>PERMINTAAN BELI CREDIT</b>\n${DIV_HTML}\n\n` +
            `<blockquote>👤 ${name} (${buyerUname})\n🆔 <code>${userId}</code>\n📦 Paket: <b>${pkg.label}</b>\n💵 Harga: <b>${formatIDR(pkg.priceIDR)}</b>\n💳 Metode: <b>${method.toUpperCase()}</b></blockquote>`,
          parseMode: "html",
          buttons: buildButtons([
            [{ text: "✅ ACC", data: `orderacc_${orderId}` }],
            [{ text: "❌ Tolak", data: `orderreject_${orderId}` }],
          ]),
        });
      } catch (_) {}

      return await sendHtml(chatId,
        `⏳ <b>Menunggu Admin...</b>\n${DIV_HTML}\n\n` +
        `<blockquote>Permintaan pembayaran <b>${method.toUpperCase()}</b> sudah dikirim ke admin.\nTunggu sebentar, admin sedang menyiapkan ${method === "qris" ? "QRIS" : "nomor DANA"}.</blockquote>`,
        [[{ text: "🏠 Menu Utama", data: "start" }]], msgId
      );
    }

    // Admin ACC permintaan metode pembayaran
    if (data.startsWith("orderacc_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Hanya Admin/Owner!", alert: true });
      const orderId = data.replace("orderacc_", "");
      const order = pendingOrders.get(orderId);
      if (!order) return await event.answer({ message: "❌ Order tidak ditemukan/expired.", alert: true });

      await event.answer({ message: "✅ Diterima." });

      if (order.method === "qris") {
        // Admin diminta upload foto QRIS, reply ke pesan ini
        modStates.set(userId, { step: "waiting_qris_photo", orderId, updatedAt: Date.now() });
        await client.sendMessage(chatId, {
          message: `📤 <b>Kirim Foto QRIS</b>\n\n<blockquote>Kirim foto QRIS sekarang untuk diteruskan ke user (order <code>${orderId}</code>).</blockquote>`,
          parseMode: "html",
        });
      } else {
        // DANA: minta admin ketik nomor DANA
        modStates.set(userId, { step: "waiting_dana_number", orderId, updatedAt: Date.now() });
        await client.sendMessage(chatId, {
          message: `📤 <b>Kirim Nomor DANA</b>\n\n<blockquote>Ketik nomor DANA tujuan sekarang untuk diteruskan ke user (order <code>${orderId}</code>).</blockquote>`,
          parseMode: "html",
        });
      }
      return;
    }

    if (data.startsWith("orderreject_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Hanya Admin/Owner!", alert: true });
      const orderId = data.replace("orderreject_", "");
      const order = pendingOrders.get(orderId);
      await event.answer({ message: "❌ Ditolak." });
      if (order) {
        pendingOrders.delete(orderId);
        try { await client.sendMessage(order.chatId, { message: `❌ <b>Permintaan beli credit kamu ditolak admin.</b>`, parseMode: "html" }); } catch (_) {}
      }
      return;
    }

    // User kirim bukti TF -> notif ke admin utk ACC final
    if (data.startsWith("orderfinalacc_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Hanya Admin/Owner!", alert: true });
      const orderId = data.replace("orderfinalacc_", "");
      const order = pendingOrders.get(orderId);
      if (!order) return await event.answer({ message: "❌ Order tidak ditemukan/expired.", alert: true });

      const pkg = CREDIT_PACKAGES[order.pkgKey];
      await event.answer({ message: "✅ Disetujui!" });

      if (pkg.kind === "reseller") {
        rdb.add(order.userId, order.buyerUname !== "—" ? order.buyerUname.replace("@", "") : null, userId);
        try {
          await client.sendMessage(order.chatId, {
            message: `🎉 <b>Top Up Berhasil!</b>\n\n<blockquote>🤝 Kamu sekarang jadi <b>Reseller</b>!\n\n🙏 Terima kasih sudah support!</blockquote>`,
            parseMode: "html",
          });
        } catch (_) {}
        credits.addBuyer(order.userId, order.buyerUname, pkg.priceIDR, 0, userId);
      } else {
        credits.addCredits(order.userId, pkg.credits);
        try {
          await client.sendMessage(order.chatId, {
            message: `🎉 <b>Top Up Berhasil!</b>\n\n<blockquote>💰 +${pkg.credits} Credit ditambahkan.\n💳 Saldo sekarang: <b>${credits.getCredits(order.userId)} Credit</b>\n\n🙏 Terima kasih sudah support!</blockquote>`,
            parseMode: "html",
          });
        } catch (_) {}
        credits.addBuyer(order.userId, order.buyerUname, pkg.priceIDR, pkg.credits, userId);
      }
      pendingOrders.delete(orderId);
      return;
    }

    if (data.startsWith("orderfinalreject_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Hanya Admin/Owner!", alert: true });
      const orderId = data.replace("orderfinalreject_", "");
      const order = pendingOrders.get(orderId);
      await event.answer({ message: "❌ Ditolak." });
      if (order) {
        pendingOrders.delete(orderId);
        try { await client.sendMessage(order.chatId, { message: `❌ <b>Bukti transfer kamu ditolak admin. Silakan hubungi admin jika ini kesalahan.</b>`, parseMode: "html" }); } catch (_) {}
      }
      return;
    }

    if (data === "redeem_start") {
      await event.answer();
      modStates.set(userId, { step: "waiting_redeem_code", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🎁 <b>Redeem Kode Credit</b>\n${DIV_HTML}\n\n<blockquote>Kirim kode redeem kamu sekarang:</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // ─── OWNER: Semua deploy web & ganti domain (URL/domain tidak pernah masuk channel) ──
    if (data.startsWith("owner_alldeploy_")) {
      if (!isOwner(userId)) return await event.answer({ message: "❌ Hanya Owner!", alert: true });
      const page = parseInt(data.replace("owner_alldeploy_", "")) || 1;
      await event.answer();
      return await showAllDeploys(chatId, page, msgId);
    }

    if (data === "owner_listbuyers") {
      if (!isOwner(userId)) return await event.answer({ message: "❌ Hanya Owner!", alert: true });
      await event.answer();
      return await showBuyerList(chatId, msgId);
    }

    // Pagination: list users
    if (data.startsWith("listusers_page_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const page = parseInt(data.replace("listusers_page_", ""));
      await event.answer();
      return await handleListUsers(chatId, userId, page, msgId);
    }

    // Pagination: list resellers
    if (data.startsWith("listresellers_page_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const page = parseInt(data.replace("listresellers_page_", ""));
      await event.answer();
      return await handleListResellers(chatId, userId, page, msgId);
    }

    // Pagination: build history
    if (data.startsWith("buildhistory_page_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const page = parseInt(data.replace("buildhistory_page_", ""));
      await event.answer();
      return await handleBuildHistory(chatId, userId, page, msgId);
    }

    // Kill build
    if (data.startsWith("kill_build_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const targetId = parseInt(data.replace("kill_build_", ""));
      const job = getUserJob(targetId);
      if (!job) return await event.answer({ message: "ℹ️ Build sudah selesai.", alert: true });
      removeUserJob(targetId);
      await event.answer({ message: `💀 Build user ${targetId} dihentikan!` });
      try { await client.sendMessage(job.chatId, { message: `⚠️ **Build kamu dihentikan paksa oleh admin.**`, parseMode: "md" }); } catch (_) {}
      return await handleListBuildsForKill(chatId, userId, msgId);
    }

    // Quick userinfo from button
    if (data.startsWith("adm_add_reseller_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const targetId = parseInt(data.replace("adm_add_reseller_", ""));
      await event.answer();
      await handleAddReseller(chatId, userId, targetId);
      return;
    }
    if (data.startsWith("adm_rm_reseller_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const targetId = parseInt(data.replace("adm_rm_reseller_", ""));
      await event.answer();
      await handleRemoveReseller(chatId, userId, targetId);
      return;
    }
    if (data.startsWith("adm_ban_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const targetId = parseInt(data.replace("adm_ban_", ""));
      await event.answer();
      await handleBanUser(chatId, userId, `${targetId} Via panel`);
      return;
    }
    if (data.startsWith("adm_unban_")) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const targetId = parseInt(data.replace("adm_unban_", ""));
      await event.answer();
      await handleUnbanUser(chatId, userId, targetId);
      return;
    }

    // Report actions
    if (data === "user_start_lapor") {
      if (db.isReportBlocked(userId)) return event.answer({ message: "❌ Kamu diblokir dari fitur laporan.", alert: true });
      userStates.set(userId, { step: "WAITING_FOR_REASON" });
      await client.editMessage(chatId, {
        message: msgId,
        text: `📝 <b>MENU LAPORAN</b>\n\n<blockquote>Ketik alasan dan detail laporan kamu dengan jelas, lalu kirim lewat chat.\n\n⚠️ Laporan palsu akan menyebabkan akun diblokir.</blockquote>`,
        parseMode: "html",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "user_cancel_lapor" }]])
      });
      return await event.answer();
    }
    if (data === "user_cancel_lapor") {
      userStates.delete(userId);
      await client.editMessage(chatId, {
        message: msgId,
        text: `❌ <b>Laporan Dibatalkan</b>\n\n<blockquote>Proses laporan dihentikan.</blockquote>`,
        parseMode: "html",
        buttons: []
      });
      return await event.answer({ message: "Laporan dibatalkan" });
    }

    // Admin panel
    if (data === "admin_panel" || data === "owner_panel") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await showAdminPanel(chatId, userId, msgId);
      return await event.answer();
    }

    if (data === "admin_add_reseller") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `➕ <b>Tambah Reseller</b>\n\n<blockquote>Gunakan: <code>/addreseller 123456789</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_remove_reseller") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `➖ <b>Hapus Reseller</b>\n\n<blockquote>Gunakan: <code>/removereseller 123456789</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_search_user") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `🔍 <b>Cari User</b>\n\n<blockquote>Gunakan:\n<code>/searchuser 123456789</code>\n<code>/searchuser @username</code>\n<code>/searchuser nama</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_userinfo") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `ℹ️ <b>Info User</b>\n\n<blockquote>Gunakan: <code>/userinfo 123456789</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_ban_user") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `🚫 <b>Ban User</b>\n\n<blockquote>Gunakan: <code>/banuser 123456789 alasan</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_unban_user") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `✅ <b>Unban User</b>\n\n<blockquote>Gunakan: <code>/unbanuser 123456789</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_list_builds") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await event.answer();
      return await handleListBuildsForKill(chatId, userId, msgId);
    }
    if (data === "admin_export_users") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await event.answer({ message: "📤 Mengekspor..." });
      return await handleExportUsers(chatId, userId);
    }
    if (data === "admin_dm_user") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      await sendHtml(chatId, `📣 <b>Kirim DM ke User</b>\n\n<blockquote>Gunakan: <code>/dmuser 123456789 pesan kamu</code></blockquote>`);
      return await event.answer();
    }
    if (data === "admin_toggle_maint") {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      const now = mdb.toggle();
      await event.answer({ message: `🛠️ Maintenance ${now ? "AKTIF" : "NONAKTIF"}!` });
      return await showAdminPanel(chatId, userId, msgId);
    }
    if (data === "admin_reset_stats") {
      if (!isOwner(userId)) return await event.answer({ message: "❌ Hanya Owner!", alert: true });
      db.resetStats();
      await event.answer({ message: "✅ Stats direset!" });
      return await showAdminPanel(chatId, userId, msgId);
    }

    // Report admin actions
    const isAdminAct = data.startsWith("adm_fix_") || data.startsWith("adm_blk_") || data.startsWith("adm_unblk_");
    if (isAdminAct) {
      if (!isPrivileged(userId)) return await event.answer({ message: "❌ Akses ditolak!", alert: true });
      let origText = "Laporan User";
      try { const m = await client.getMessages(chatId, { ids: [msgId] }); origText = m[0]?.message || m[0]?.caption || origText; } catch (_) {}

      if (data.startsWith("adm_fix_")) {
        const tid = Number(data.replace("adm_fix_", ""));
        try {
          await client.sendMessage(tid, { message: `🎉 **LAPORAN SELESAI!**\n\nKendala yang kamu laporkan telah diperbaiki oleh admin. Terima kasih!`, parseMode: "md" });
          await event.answer({ message: "✅ User diberitahu!" });
        } catch (_) { await event.answer({ message: "⚠️ Gagal kirim DM!", alert: true }); }
        await client.editMessage(chatId, { message: msgId, text: origText + "\n\n🟢 **STATUS:** Selesai & user diberitahu.", parseMode: "md", buttons: buildButtons([[{ text: "🔒 Blokir", data: `adm_blk_${tid}` }]]) });
        return;
      }
      if (data.startsWith("adm_blk_")) {
        const tid = Number(data.replace("adm_blk_", ""));
        if (db.isReportBlocked(tid)) return await event.answer({ message: "ℹ️ Sudah diblokir.", alert: true });
        db.blockReportUser(tid);
        await event.answer({ message: `🔒 User ${tid} diblokir!` });
        await client.editMessage(chatId, { message: msgId, text: origText + "\n\n🔴 **STATUS:** User diblokir.", parseMode: "md", buttons: buildButtons([[{ text: "🔓 Unblokir", data: `adm_unblk_${tid}` }]]) });
        try { await client.sendMessage(tid, { message: `⚠️ **DIBLOKIR!**\n\nFitur laporan kamu dinonaktifkan.`, parseMode: "md" }); } catch (_) {}
        return;
      }
      if (data.startsWith("adm_unblk_")) {
        const tid = Number(data.replace("adm_unblk_", ""));
        if (!db.isReportBlocked(tid)) return await event.answer({ message: "ℹ️ Tidak dalam blokir.", alert: true });
        db.unblockReportUser(tid);
        await event.answer({ message: `🔓 User ${tid} diunblokir!` });
        await client.editMessage(chatId, { message: msgId, text: origText + "\n\n⚪ **STATUS:** Akses normal.", parseMode: "md", buttons: buildButtons([[{ text: "✅ Selesai", data: `adm_fix_${tid}` }, { text: "🔒 Blokir", data: `adm_blk_${tid}` }]]) });
        try { await client.sendMessage(tid, { message: `✅ **AKSES DIKEMBALIKAN!**\n\nFitur laporan kamu aktif kembali.`, parseMode: "md" }); } catch (_) {}
        return;
      }
    }

    // Check join
    if (data === "check_join") {
      const joined = await isJoinedChannel(userId);
      if (!joined) return event.answer({ message: "❌ Belum join semua channel!", alert: true });
      await event.answer({ message: "✅ Verifikasi berhasil!" });
      let firstName = "User";
      try { const e = await client.getEntity(userId); firstName = e?.firstName || "User"; } catch (_) {}
      return handleStart({ chatId, message: { getSender: async () => ({ id: userId, firstName, username: null }) } }, msgId);
    }

    await event.answer();

    // Main navigation
    if (data === "start") {
      return await handleStart({
        chatId,
        message: {
          getSender: async () => {
            try { const e = await client.getEntity(userId); return { id: userId, firstName: e?.firstName || "User", username: e?.username || null }; }
            catch (_) { return { id: userId, firstName: "User" }; }
          }
        }
      }, msgId);
    }
    if (data === "build")         return await handleBuild(chatId, userId, null,      msgId);
    if (data === "build_debug")   return await handleBuild(chatId, userId, "debug",   msgId);
    if (data === "build_release") return await handleBuild(chatId, userId, "release", msgId);
    if (data === "web2apk")       return await handleWeb2Apk(chatId, userId, msgId);
    if (data === "queue")         return await handleQueue(chatId, msgId);
    if (data === "help")          return await handleHelp(chatId, msgId);
    if (data === "status")        return await handleStatus(chatId, userId, msgId);

    if (data === "cancel") {
      removeUserJob(userId);
      modStates.delete(userId);
      return await sendHtml(chatId,
        `✅ <b>Dibatalkan.</b>\n\n<blockquote>Ketik /start atau klik tombol di bawah untuk kembali ke menu utama.</blockquote>`,
        [[{ text: "🏠 Menu Utama", data: "start" }]], msgId
      );
    }

    // MOD: GANTI DOMAIN
    if (data === "mod_domain_start") {
      if (isUserBuilding(userId)) {
        return await sendHtml(chatId,
          `⚠️ <b>Build Sedang Aktif!</b>\n\n<blockquote>Selesaikan atau batalkan build kamu dulu sebelum ganti domain.</blockquote>`,
          [[{ text: "❌ Batalkan Build", data: "cancel" }]], msgId
        );
      }
      modStates.set(userId, { step: "waiting_zip_domain", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🔧 <b>Ganti Domain APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `📤 Kirim file <code>.zip</code> project Flutter kamu.\n\n` +
        `Bot akan cari semua URL <code>http://</code> / <code>https://</code> di file <code>.dart</code>, lalu kamu tinggal pilih mana yang mau diganti.` +
        `</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // MOD: RENAME ALL NAME (cari-ganti teks bebas di semua file)
    if (data === "mod_renameall_start") {
      if (isUserBuilding(userId)) {
        return await sendHtml(chatId,
          `⚠️ <b>Build Sedang Aktif!</b>\n\n<blockquote>Selesaikan atau batalkan build kamu dulu.</blockquote>`,
          [[{ text: "❌ Batalkan Build", data: "cancel" }]], msgId
        );
      }
      modStates.set(userId, { step: "waiting_zip_renameall", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🔤 <b>Rename All Name</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>📤 Kirim file <code>.zip</code> project Flutter kamu.\n\n` +
        `Bot akan ganti SEMUA kemunculan teks lama menjadi teks baru, di semua file sekaligus (bukan cuma domain).</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    if (data.startsWith("mod_pickurl_")) {
      const state = modStates.get(userId);
      if (!state || state.step !== "waiting_pick_url") {
        return await sendHtml(chatId, `⚠️ <b>Sesi kedaluwarsa.</b> Mulai ulang dari menu.`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      const idx = parseInt(data.replace("mod_pickurl_", ""), 10);
      const picked = state.foundUrls?.[idx];
      if (!picked) {
        return await sendHtml(chatId, `❌ <b>Pilihan tidak valid.</b>`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      state.oldUrl = picked[0];
      state.step = "waiting_new_url";
      modStates.set(userId, state);
      return await sendHtml(chatId,
        `🔧 <b>Ganti Domain APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>✅ URL lama: <code>${state.oldUrl}</code></blockquote>\n\n` +
        `Sekarang kirim <b>URL server baru</b> (contoh: <code>http://panelkulegalv4.xzcl.web.id:9049</code>):`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // MOD: GANTI WARNA
    if (data === "mod_color_start") {
      if (isUserBuilding(userId)) {
        return await sendHtml(chatId,
          `⚠️ <b>Build Sedang Aktif!</b>\n\n<blockquote>Selesaikan atau batalkan build kamu dulu sebelum ganti warna.</blockquote>`,
          [[{ text: "❌ Batalkan Build", data: "cancel" }]], msgId
        );
      }
      modStates.set(userId, { step: "waiting_zip_color", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🎨 <b>Ganti Warna APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `📤 Kirim file <code>.zip</code> project Flutter kamu.\n\n` +
        `Bot akan deteksi warna utama (theme + splash) secara otomatis, lalu kamu pilih warna pengganti.` +
        `</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    if (data.startsWith("mod_preset_")) {
      const state = modStates.get(userId);
      if (!state || state.step !== "waiting_pick_color") {
        return await sendHtml(chatId, `⚠️ <b>Sesi kedaluwarsa.</b> Mulai ulang dari menu.`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      const presetKey = data.replace("mod_preset_", "");
      const newHex = fluttermod.COLOR_PRESETS[presetKey];
      if (!newHex) {
        return await sendHtml(chatId, `❌ <b>Preset tidak dikenal.</b>`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      return await processColorChange(chatId, userId, state, newHex, msgId);
    }

    if (data === "mod_custom_color") {
      const state = modStates.get(userId);
      if (!state || state.step !== "waiting_pick_color") {
        return await sendHtml(chatId, `⚠️ <b>Sesi kedaluwarsa.</b> Mulai ulang dari menu.`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      state.step = "waiting_custom_hex";
      modStates.set(userId, state);
      return await sendHtml(chatId,
        `🎨 <b>Warna Custom</b>\n\n<blockquote>Kirim kode hex warna kamu (6 digit, tanpa #).\nContoh: <code>FF5733</code></blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // MOD: GANTI ICON
    if (data === "mod_icon_start") {
      if (isUserBuilding(userId)) {
        return await sendHtml(chatId,
          `⚠️ <b>Build Sedang Aktif!</b>\n\n<blockquote>Selesaikan atau batalkan build kamu dulu sebelum ganti icon.</blockquote>`,
          [[{ text: "❌ Batalkan Build", data: "cancel" }]], msgId
        );
      }
      modStates.set(userId, { step: "waiting_zip_icon", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🖼️ <b>Ganti Icon APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `📤 Kirim file <code>.zip</code> project Flutter kamu.\n\n` +
        `Bot akan cek icon Android & iOS yang ada di project.` +
        `</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // MOD: GANTI NAMA
    if (data === "mod_name_start") {
      if (isUserBuilding(userId)) {
        return await sendHtml(chatId,
          `⚠️ <b>Build Sedang Aktif!</b>\n\n<blockquote>Selesaikan atau batalkan build kamu dulu sebelum ganti nama.</blockquote>`,
          [[{ text: "❌ Batalkan Build", data: "cancel" }]], msgId
        );
      }
      modStates.set(userId, { step: "waiting_zip_name", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `✏️ <b>Ganti Nama APK</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `📤 Kirim file <code>.zip</code> project Flutter kamu.\n\n` +
        `Bot akan ganti nama app di AndroidManifest, strings.xml, dan Info.plist (iOS).` +
        `</blockquote>`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // DEPLOY WEB KE VERCEL
    if (data === "deployweb_start") {
      if (!webdeploy.isConfigured()) {
        return await sendHtml(chatId,
          `⚠️ <b>Fitur Belum Dikonfigurasi</b>\n\n<blockquote>Owner belum mengatur GITHUB_TOKEN / GITHUB_USERNAME / VERCEL_TOKEN di server.</blockquote>`,
          [[{ text: "🏠 Menu Utama", data: "start" }]], msgId
        );
      }
      modStates.set(userId, { step: "deployweb_waiting_name", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🚀 <b>Deploy Web ke Vercel</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `📝 Masukkan nama untuk subdomain kamu.\n\n` +
        `Contoh: <code>tokoklontongziper</code> → jadi\n` +
        `<code>https://tokoklontongziper.vercel.app</code>` +
        `</blockquote>\n\n` +
        `⚠️ Hanya huruf kecil (a-z) & angka (0-9), min 3 karakter, tanpa spasi/simbol.`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    // ENKRIPSI: MENU UTAMA
    if (data === "enc_menu") {
      modStates.delete(userId);
      return await sendHtml(chatId,
        `🔐 <b>Menu Enkripsi</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<blockquote>` +
        `🌐 <b>Enkripsi HTML</b> — Base64 wrap / Obfuscate hex / Dekripsi\n\n` +
        `⚡ <b>Enkripsi JS</b> — 15+ mode (Standard, Ultra, Quantum, Nebula, dll)` +
        `</blockquote>`,
        [
          [{ text: "🌐 Enkripsi HTML", data: "enc_html_menu", style: "Success" }],
          [{ text: "⚡ Enkripsi JS", data: "enc_js_menu", style: "primary" }],
          [{ text: "🏠 Menu Utama", data: "start", style: "Danger" }],
        ], msgId
      );
    }

    if (data === "enc_html_menu") {
      return await sendHtml(chatId,
        `🌐 <b>Enkripsi HTML</b>\n${DIV_HTML}\n\n` +
        `<blockquote>` +
        `🔐 Base64 — HTML di-encode Base64, auto decode di browser\n` +
        `🌀 Obfuscate — Kode dikacak pakai hex encoding\n` +
        `🔓 Dekripsi — Kembalikan HTML terenkripsi ke original` +
        `</blockquote>`,
        [
          [{ text: "🔐 Base64 HTML", data: "enc_html_b64", style: "Success" }],
          [{ text: "🌀 Obfuscate HTML", data: "enc_html_obf", style: "Success" }],
          [{ text: "🔓 Dekripsi HTML", data: "dec_html_b64", style: "Success" }],
          [{ text: "‹ Kembali", data: "enc_menu", style: "Danger" }],
        ], msgId
      );
    }

    if (data === "enc_html_b64" || data === "enc_html_obf" || data === "dec_html_b64") {
      modStates.set(userId, { step: data, chatId, updatedAt: Date.now() });
      const label = data === "enc_html_b64" ? "Enkripsi Base64" : data === "enc_html_obf" ? "Enkripsi Obfuscate" : "Dekripsi";
      return await sendHtml(chatId,
        `🌐 <b>${label} HTML</b>\n${DIV_HTML}\n\n📤 Kirim file <code>.html</code> atau paste kode HTML:`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    if (data === "enc_js_menu") {
      if (!jsenc.isAvailable) {
        return await sendHtml(chatId,
          `⚠️ <b>Modul js-confuser tidak terinstall di server.</b>\n\n<blockquote>Owner perlu jalankan <code>npm install js-confuser</code> di server bot.</blockquote>`,
          [[{ text: "🏠 Menu Utama", data: "start" }]], msgId
        );
      }
      const modeLabels = {
        standard: "Standard", strong: "Strong", ultra: "Ultra", quantum: "Quantum",
        timelocked: "TimeLocked", nebula: "Nebula", nexus: "Nexus", siu: "SiuCalcrick",
        mandarin: "Mandarin", arab: "Arab", japan: "Japan", japxab: "JapanXArab",
        invis: "Invisible", stealth: "Stealth", big: "Big", max: "Max", custom: "Custom",
      };
      const rows = [];
      const modes = jsenc.JS_MODES;
      for (let i = 0; i < modes.length; i += 2) {
        const pair = modes.slice(i, i + 2).map(m => ({ text: modeLabels[m] || m, data: `ejs_${m}`, style: "Success" }));
        rows.push(pair);
      }
      rows.push([{ text: "🔓 Dekripsi JS", data: "dec_js_b64", style: "primary" }]);
      rows.push([{ text: "‹ Kembali", data: "enc_menu", style: "Danger" }]);

      return await sendHtml(chatId,
        `⚡ <b>Enkripsi JS — Pilih Mode</b>\n${DIV_HTML}\n\n` +
        `<blockquote>Pilih salah satu mode enkripsi di bawah, lalu kirim file <code>.js</code>.</blockquote>`,
        rows, msgId
      );
    }

    if (data.startsWith("ejs_")) {
      const mode = data.replace("ejs_", "");
      if (!jsenc.JS_MODES.includes(mode)) {
        return await sendHtml(chatId, `❌ <b>Mode tidak dikenal.</b>`, [[{ text: "🏠 Menu Utama", data: "start" }]], msgId);
      }
      modStates.set(userId, { step: "enc_js_wait", jsMode: mode, chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `⚡ <b>Mode: ${mode}</b>\n${DIV_HTML}\n\n📤 Kirim file <code>.js</code> kamu (maks 10MB):`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }

    if (data === "dec_js_b64") {
      modStates.set(userId, { step: "dec_js_b64", chatId, updatedAt: Date.now() });
      return await sendHtml(chatId,
        `🔓 <b>Dekripsi JS</b>\n${DIV_HTML}\n\n📤 Kirim file <code>.js</code> yang terenkripsi (Base64):`,
        [[{ text: "❌ Batalkan", data: "cancel", style: "Danger" }]], msgId
      );
    }
  } catch (err) {
    console.error("Callback error:", err);
  }
}

// ─── MAIN ────────────────────────────────────────────────────────────────────
async function main() {
  console.log(`🚀 Starting ${CONFIG.BOT_NAME}...`);
  console.log(`👑 OWNER_ID: ${CONFIG.OWNER_ID}`);
  console.log(`🎯 PRIORITY: Owner (1) > Reseller (2) > User (3)`);

  if (!fs.existsSync(CONFIG.TMP_DIR)) fs.mkdirSync(CONFIG.TMP_DIR, { recursive: true });

  await client.start({ botAuthToken: CONFIG.BOT_TOKEN, onError: err => console.error("Client error:", err) });
  fs.writeFileSync(SESSION_FILE, client.session.save());
  console.log("✅ Bot connected & session saved!");

  client.addEventHandler(async (event) => {
    try {
      const msg    = event.message;
      const text   = msg?.text?.trim();
      const chatId = event.chatId;
      const userId = Number(msg.senderId);

      if (text === "/start" || text?.startsWith("/start ")) {
        const refPayload = text.includes(" ") ? text.split(" ")[1]?.trim() : null;
        return handleStart(event, null, refPayload);
      }
      if (text === "/help")   return handleHelp(chatId);

      if (text === "/broadcast" && isPrivileged(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return sendHtml(chatId, `⚠️ <b>Cara Broadcast:</b>\n\n<blockquote>Reply pesan yang ingin di-broadcast, lalu ketik /broadcast</blockquote>`);
        isOwner(userId)
          ? await (async () => {
              const all = db.getAllUsers();
              const m   = await sendHtml(chatId, `📢 <b>Broadcast dimulai ke ${all.length} user...</b>`);
              let ok = 0, fail = 0;
              for (const u of all) {
                try {
                  replied.media
                    ? await client.sendFile(u.userId, { file: replied.media, caption: replied.text || "", parseMode: "md" })
                    : await client.sendMessage(u.userId, { message: replied.text || "", parseMode: "md" });
                  ok++;
                } catch (_) { fail++; }
                await sleep(100);
              }
              await editHtml(chatId, m.id, `✅ <b>Broadcast Selesai!</b>\n\n<blockquote>📢 Total: ${all.length}\n✔️ Sukses: ${ok}\n❌ Gagal: ${fail}</blockquote>`);
            })()
          : await handleBroadcastWithOwnerNotify(chatId, userId, replied);
        return;
      }

      if (text?.startsWith("/addreseller") && isPrivileged(userId)) {
        const parts = text.split(" ");
        return handleAddReseller(chatId, userId, parts[1]);
      }
      if (text?.startsWith("/removereseller") && isPrivileged(userId)) {
        const parts = text.split(" ");
        return handleRemoveReseller(chatId, userId, parts[1]);
      }
      if ((text === "/listusers" || text?.match(/^\/listusers\s+\d+$/)) && isPrivileged(userId)) {
        const page = text.includes(" ") ? parseInt(text.split(" ")[1]) : 1;
        return handleListUsers(chatId, userId, page);
      }
      if ((text === "/listresellers" || text?.match(/^\/listresellers\s+\d+$/)) && isPrivileged(userId)) {
        const page = text.includes(" ") ? parseInt(text.split(" ")[1]) : 1;
        return handleListResellers(chatId, userId, page);
      }
      if (text?.startsWith("/searchuser") && isPrivileged(userId)) {
        return handleSearchUser(chatId, userId, text.replace("/searchuser", "").trim());
      }
      if (text?.startsWith("/userinfo") && isPrivileged(userId)) {
        return handleUserInfo(chatId, userId, text.replace("/userinfo", "").trim());
      }
      if (text?.startsWith("/deleteuser") && isPrivileged(userId)) {
        return handleDeleteUser(chatId, userId, text.replace("/deleteuser", "").trim());
      }
      if (text?.startsWith("/banuser") && isPrivileged(userId)) {
        return handleBanUser(chatId, userId, text.replace("/banuser", "").trim());
      }
      if (text?.startsWith("/unbanuser") && isPrivileged(userId)) {
        return handleUnbanUser(chatId, userId, text.replace("/unbanuser", "").trim());
      }
      if (text?.startsWith("/dmuser") && isPrivileged(userId)) {
        return handleDmUser(chatId, userId, text.replace("/dmuser", "").trim());
      }
      if (text === "/exportusers" && isPrivileged(userId)) {
        return handleExportUsers(chatId, userId);
      }
      if ((text === "/buildhistory" || text?.match(/^\/buildhistory\s+\d+$/)) && isPrivileged(userId)) {
        const page = text.includes(" ") ? parseInt(text.split(" ")[1]) : 1;
        return handleBuildHistory(chatId, userId, page);
      }
      if (text?.startsWith("/killbuild") && isPrivileged(userId)) {
        const targetId = parseInt(text.replace("/killbuild", "").trim());
        if (!isNaN(targetId)) {
          const job = getUserJob(targetId);
          if (!job) return sendHtml(chatId, `❌ <b>User ID <code>${targetId}</code> tidak sedang build.</b>`);
          removeUserJob(targetId);
          await sendHtml(chatId, `💀 <b>Build user <code>${targetId}</code> dihentikan paksa!</b>`);
          try { await client.sendMessage(job.chatId, { message: `⚠️ **Build kamu dihentikan paksa oleh admin.**`, parseMode: "md" }); } catch (_) {}
        }
        return;
      }

      if (text?.startsWith("/redeem")) {
        const code = text.replace("/redeem", "").trim();
        if (!code) return sendHtml(chatId, `🎁 <b>Redeem Kode</b>\n\n<blockquote>Gunakan: <code>/redeem KODE-KAMU</code></blockquote>`);
        const res = credits.redeemCode(userId, code);
        if (!res.ok) {
          const reasonMsg = { notfound: "Kode tidak ditemukan.", exhausted: "Kode sudah habis dipakai.", already: "Kamu sudah pernah pakai kode ini." }[res.reason] || "Kode tidak valid.";
          return sendHtml(chatId, `❌ <b>Gagal Redeem!</b>\n\n<blockquote>${reasonMsg}</blockquote>`);
        }
        try {
          let name = "Unknown", uname = "—";
          try {
            const e = await client.getEntity(userId);
            name = [e?.firstName, e?.lastName].filter(Boolean).join(" ") || "Unknown";
            uname = e?.username ? `@${e.username}` : "—";
          } catch (_) {}
          await client.sendMessage(CONFIG.CHANNEL_USERNAME, {
            message: `🎁 <b>KODE REDEEM DIPAKAI</b>\n${DIV_HTML}\n\n<blockquote>👤 ${name} (${uname})\n💰 +${res.credits} Credit</blockquote>`,
            parseMode: "html",
          });
        } catch (_) {}
        return sendHtml(chatId, `🎉 <b>Redeem Berhasil!</b>\n\n<blockquote>💰 +${res.credits} Credit\n💳 Saldo: <b>${credits.getCredits(userId)} Credit</b></blockquote>`);
      }

      if (text?.startsWith("/gencode") && isPrivileged(userId)) {
  const parts = text.split(" ");
  const amount = Number(parts[1]);
  const maxUses = Number(parts[2]) || 1;
  
  if (!amount) {
    return sendHtml(chatId, `
🔑 <b>Generate Kode Redeem</b>

<blockquote>Gunakan: <code>/gencode &lt;jumlah_credit&gt; [max_pemakaian]</code>
Contoh: <code>/gencode 10 5</code></blockquote>
`);
  }
  
  const code = credits.createRedeemCode(amount, maxUses, userId);
  return sendHtml(chatId, `
  <blockquote>🎁 KODE REDEEM BARU!</blockquote>
<blockquote>┣ 🔑 Kode : <code>${code}</code>
┣ 💰 Hadiah : <b>${amount}</b> CREDIT
┗ 👥 Kuota : <b>${maxUses}</b></blockquote>

<blockquote>📌 Cara Klaim:
Buka bot @memeayahhajak_bot lalu ketik:
/redeem <code>${code}</code></blockquote>
`);
}

      if (text?.startsWith("/addcredit") && isPrivileged(userId)) {
        const parts = text.split(" ");
        const targetId = Number(parts[1]);
        const amount = Number(parts[2]);
        if (!targetId || !amount) return sendHtml(chatId, `💰 <b>Tambah Credit</b>\n\n<blockquote>Gunakan: <code>/addcredit &lt;user_id&gt; &lt;jumlah&gt;</code></blockquote>`);
        const newBal = credits.addCredits(targetId, amount);
        try { await client.sendMessage(targetId, { message: `🎉 <b>Kamu Dapat Bonus Credit!</b>\n\n<blockquote>💰 +${amount} Credit dari admin.\n💳 Saldo: <b>${newBal}</b></blockquote>`, parseMode: "html" }); } catch (_) {}
        return sendHtml(chatId, `✅ <b>Berhasil!</b>\n\n<blockquote>User <code>${targetId}</code> sekarang punya <b>${newBal} Credit</b>.</blockquote>`);
      }

      if (text === "/alldeploy" && isOwner(userId)) return showAllDeploys(chatId, 1);
      if (text === "/listbuyers" && isOwner(userId)) return showBuyerList(chatId);

      if (text === "/backup" && isOwner(userId)) {
        const m = await sendHtml(chatId, `🔄 <b>Mempersiapkan backup data_credits...</b>`);
        try {
          const result = credits.downloadLocalBackup();
          if (result.ok) {
            const fileSizeMB = (result.size / 1024 / 1024).toFixed(2);
            await client.sendFile(chatId, {
              file: result.path,
              caption: `✅ <b>Backup Berhasil!</b>\n\n📦 File: <code>data_credits_backup.zip</code>\n📊 Ukuran: <code>${fileSizeMB} MB</code>\n⏰ Waktu: <code>${new Date().toLocaleString("id-ID")}</code>\n\n📂 Isi file:\n  • credits.json\n  • redeem.json\n  • deploys.json\n  • buyers.json\n  • BACKUP_INFO.json`,
              parseMode: "html"
            });
            // Hapus pesan lama
            try { await client.deleteMessages(chatId, [m.id]); } catch (_) {}
          } else {
            return editHtml(chatId, m.id, `❌ <b>Backup Gagal!</b>\n\n<blockquote>${result.reason}</blockquote>`);
          }
        } catch (err) {
          return editHtml(chatId, m.id, `❌ <b>Backup Gagal!</b>\n\n<blockquote>${err.message}</blockquote>`);
        }
      }

      if (text === "/dbbackup" && isOwner(userId)) {
        const m = await sendHtml(chatId, `🔄 <b>Membackup database ke GitHub...</b>`);
        const result = await credits.backupToGithub({
          "users.json": fs.readFileSync(DB_PATH, "utf-8"),
          "resellers.json": fs.readFileSync(RESELLER_PATH, "utf-8"),
          "banned.json": fs.readFileSync(BANNED_PATH, "utf-8"),
          "buildhistory.json": fs.readFileSync(HISTORY_PATH, "utf-8"),
        });
        return editHtml(chatId, m.id, result.ok
          ? `✅ <b>Backup Berhasil!</b>\n\n<blockquote>📦 Repo: <code>${result.repo}</code>\n🔗 ${result.url}</blockquote>`
          : `❌ <b>Backup Gagal!</b>\n\n<blockquote>${result.reason}</blockquote>`);
      }

      const reported = await handleUserReportMessages(event);
      if (reported) return;

      const modHandled = await handleModMessage(event);
      if (modHandled) return;

      const job = getUserJob(userId);
      if (job?.type === "web2apk") {
        if (job.status === "waiting_url"     && text?.startsWith("http")) return handleWeb2ApkUrl(event);
        if (job.status === "waiting_appname" && text)                     return handleWeb2ApkName(event);
        if (job.status === "waiting_icon"    && msg.media)                return handleWeb2ApkIcon(event);
      }

      if (msg.media) await handleZipFile(event);
    } catch (err) { console.error("Handler error:", err); }
  }, new NewMessage({}));

  client.addEventHandler(async (event) => {
    try { await handleCallback(event); }
    catch (err) { console.error("Callback error:", err); }
  }, new CallbackQuery({}));

  // Auto-backup database ke GitHub tiap 30 menit — biar kalau server mati/hilang,
  // data user & credit tetap aman dan bisa dipulihkan lewat bot.
  if (credits.isGithubConfigured()) {
    setInterval(async () => {
      try {
        await credits.backupToGithub({
          "users.json": fs.readFileSync(DB_PATH, "utf-8"),
          "resellers.json": fs.readFileSync(RESELLER_PATH, "utf-8"),
          "banned.json": fs.readFileSync(BANNED_PATH, "utf-8"),
          "buildhistory.json": fs.readFileSync(HISTORY_PATH, "utf-8"),
        });
        console.log("[Backup] Database berhasil di-backup ke GitHub.");
      } catch (err) {
        console.error("[Backup] Gagal backup:", err.message);
      }
    }, 30 * 60 * 1000);
  }

  console.log(`🤖 ${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION} aktif!`);
  await new Promise(() => {});
}

main();