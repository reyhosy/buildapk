const path = require("path");

module.exports = {
  BOT_NAME: "BOT BUILD REY",
  BOT_VERSION: "1.0",
  
  // Token bot
  BOT_TOKEN: process.env.BOT_TOKEN || "8247566943:AAEBAfdb7-ZBBybVxoJDeSZjEpvIudXNoRA",
  
  // API Telegram
  API_ID: parseInt(process.env.API_ID || "30595675"),
  API_HASH: process.env.API_HASH || "c83857e908c6c83876ba692261127287",
  
  // Owner & Admin
  OWNER_ID: parseInt(process.env.OWNER_ID || "8887449085"),
  ADMIN_IDS: (process.env.ADMIN_IDS || "8887449085").split(",").map(Number).filter(Boolean),
  
  // Channel
  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "@BUILDAPKREY",
  CHANNEL_USERNAME2: process.env.CHANNEL_USERNAME2 || "",
  CHANNEL_USERNAME3: process.env.CHANNEL_USERNAME3 || "",
  CHANNEL_USERNAME4: process.env.CHANNEL_USERNAME4 || "",
  CHANNEL_USERNAME5: process.env.CHANNEL_USERNAME5 || "",
  CHANNEL_USERNAME6: process.env.CHANNEL_USERNAME6 || "",
  
  // GitHub & Vercel
  GITHUB_TOKEN: process.env.GITHUB_TOKEN || "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",
  GITHUB_USERNAME: process.env.GITHUB_USERNAME || "reyhosy",
  VERCEL_TOKEN: process.env.VERCEL_TOKEN || "vcp_8jtxbdaDUSTc2Z4ydV8dwAK8TUCbyO1UjdDMFKqkdB8wCKFs9p4JLr5A",
  VERCEL_TEAM_ID: process.env.VERCEL_TEAM_ID || "team_WnX1dqR6fK3MD8KGS8Eigg0H",
  
  // PHOTO - PAKAI FILE LOKAL
  WELCOME_PHOTO: path.join(__dirname, "images", "welcome.jpg"),
  PHOTO_BUILD_APK: path.join(__dirname, "images", "build.jpg"),
  PHOTO_WEB2APK: path.join(__dirname, "images", "web2apk.jpg"),
  PHOTO_DEPLOY_WEB: path.join(__dirname, "images", "deploy.jpg"),
  PHOTO_ENC_HTML: path.join(__dirname, "images", "enc_html.jpg"),
  PHOTO_ENC_JS: path.join(__dirname, "images", "enc_js.jpg"),
  PHOTO_MOD_DOMAIN: path.join(__dirname, "images", "mod_domain.jpg"),
  PHOTO_MOD_COLOR: path.join(__dirname, "images", "mod_color.jpg"),
  PHOTO_MOD_ICON: path.join(__dirname, "images", "mod_icon.jpg"),
  PHOTO_MOD_NAME: path.join(__dirname, "images", "mod_name.jpg"),
  PHOTO_NEW_USER: path.join(__dirname, "images", "new_user.jpg"),
  PHOTO_REPORT_BUG: path.join(__dirname, "images", "report.jpg"),
  
  // Directories
  TMP_DIR: "./tmp",
  
  // Build settings
  BUILD_TIMEOUT_MS: 30 * 60 * 1000,
  POLL_INTERVAL_MS: 7000,
  WEB2APK_MAINTENANCE: false,
};